
  # Join Waitlist Website

  This is a code bundle for Join Waitlist Website. The original project is available at https://www.figma.com/design/l1lltoTallC2J6WREOGr1o/Join-Waitlist-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  