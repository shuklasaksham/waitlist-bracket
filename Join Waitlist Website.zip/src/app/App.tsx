import LandingPageWaitlist from '../imports/LandingPageWaitlist101';

export default function App() {
  return (
    <div className="flex justify-center bg-white min-h-screen">
      <LandingPageWaitlist />
    </div>
  );
}