function Group() {
  return (
    <div className="absolute contents left-px top-0">
      <div className="absolute h-[96px] left-px pointer-events-none top-0 w-[1440px]" data-name="Overlay">
        <div aria-hidden="true" className="absolute inset-0">
          <div className="absolute bg-[rgba(68,68,68,0.6)] inset-0 mix-blend-lighten" />
          <div className="absolute bg-[#eee] inset-0" />
          <div className="absolute backdrop-blur-[8px] bg-[#111] inset-0 mix-blend-plus-lighter" />
        </div>
        <div aria-hidden="true" className="absolute border-0 border-black border-solid inset-0" />
      </div>
    </div>
  );
}

function BgNavbar() {
  return (
    <div className="absolute contents left-0 top-0" data-name="bg-navbar">
      <Group />
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-0 top-0">
      <BgNavbar />
    </div>
  );
}

export default function Frame() {
  return (
    <div className="relative size-full">
      <Group1 />
    </div>
  );
}