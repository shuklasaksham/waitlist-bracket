function Frame1() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[1440px]">
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
    </div>
  );
}

function Frame() {
  return (
    <div className="absolute content-stretch flex items-center left-0 top-0 w-[1456px]">
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[1440px]">
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
    </div>
  );
}

function Frame3() {
  return (
    <div className="absolute content-stretch flex items-center left-0 top-0 w-[1456px]">
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[1440px]">
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
    </div>
  );
}

function Frame5() {
  return (
    <div className="absolute content-stretch flex items-center left-0 top-0 w-[1456px]">
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default function BgSurface() {
  return (
    <div className="opacity-3 relative size-full" data-name="bg-surface-101">
      <div className="-translate-x-1/2 absolute content-stretch flex flex-col gap-[10px] h-[1168.364px] items-start left-1/2 top-[1168.36px] w-[1440px]" data-name="bg-mesh">
        <Frame1 />
        <Frame />
      </div>
      <div className="-translate-x-1/2 absolute content-stretch flex flex-col gap-[10px] h-[1168.364px] items-start left-1/2 top-[1279.64px] w-[1440px]" data-name="bg-mesh">
        <Frame2 />
        <Frame3 />
      </div>
      <div className="-translate-x-1/2 absolute content-stretch flex flex-col gap-[10px] h-[1168.364px] items-start left-1/2 top-0 w-[1440px]" data-name="bg-mesh">
        <Frame4 />
        <Frame5 />
      </div>
    </div>
  );
}