export default function Video() {
  return (
    <div className="relative size-full" data-name="video-1">
      <div className="absolute h-[240px] left-0 rounded-[20px] top-0 w-[400px]" data-name="61273222 1">
        <div className="absolute inset-0 overflow-hidden rounded-[20px]">
          <video autoPlay className="absolute h-[100.08%] left-[-3%] max-w-none top-[-0.04%] w-[106.75%]" controlsList="nodownload" loop playsInline>
            <source src="/_videos/v1/a35a8bf8b4ff62d1010c9535a31344ce72871f19" />
          </video>
        </div>
        <div aria-hidden="true" className="absolute border border-black border-solid inset-0 pointer-events-none rounded-[20px]" />
      </div>
    </div>
  );
}