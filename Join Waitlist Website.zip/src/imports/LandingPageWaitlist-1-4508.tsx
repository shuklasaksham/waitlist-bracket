import svgPaths from "./svg-lkh4z7izfn";
import imgImage1 from "figma:asset/5f67aa4bdf1c70dc605145f809e72f8f90a4ea03.png";
import imgLiInBug1 from "figma:asset/eb0a7e1284e631d80c3225c0e2d6c7af931de535.png";

function Frame2() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[1440px]">
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute content-stretch flex items-center left-0 top-0 w-[1456px]">
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[1440px]">
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
    </div>
  );
}

function Frame4() {
  return (
    <div className="absolute content-stretch flex items-center left-0 top-0 w-[1456px]">
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[1440px]">
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
    </div>
  );
}

function Frame6() {
  return (
    <div className="absolute content-stretch flex items-center left-0 top-0 w-[1456px]">
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
    </div>
  );
}

function BgSurface() {
  return (
    <div className="-translate-x-1/2 absolute contents left-[calc(50%+8px)] top-0" data-name="bg-surface">
      <div className="-translate-x-1/2 absolute content-stretch flex flex-col gap-[10px] h-[1168.364px] items-start left-[calc(50%+8px)] opacity-3 top-[1168.36px] w-[1456px]" data-name="bg-mesh">
        <Frame2 />
        <Frame1 />
      </div>
      <div className="-translate-x-1/2 absolute content-stretch flex flex-col gap-[10px] h-[1168.364px] items-start left-[calc(50%+8px)] opacity-3 top-[1279.64px] w-[1456px]" data-name="bg-mesh">
        <Frame3 />
        <Frame4 />
      </div>
      <div className="-translate-x-1/2 absolute content-stretch flex flex-col gap-[10px] h-[1168.364px] items-start left-[calc(50%+8px)] opacity-3 top-0 w-[1456px]" data-name="bg-mesh">
        <Frame5 />
        <Frame6 />
      </div>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-0 top-0">
      <div className="absolute h-[96px] left-0 pointer-events-none top-0 w-[1440px]" data-name="Overlay">
        <div aria-hidden="true" className="absolute inset-0">
          <div className="absolute bg-[rgba(68,68,68,0.6)] inset-0 mix-blend-lighten" />
          <div className="absolute bg-[#eee] inset-0" />
          <div className="absolute backdrop-blur-[8px] bg-[#111] inset-0 mix-blend-plus-lighter" />
        </div>
        <div aria-hidden="true" className="absolute border-0 border-black border-solid inset-0" />
      </div>
    </div>
  );
}

function BgNavbar() {
  return (
    <div className="absolute contents left-[-1px] top-0" data-name="bg-navbar">
      <Group />
      <div className="absolute bg-white h-[96px] left-[-1px] opacity-70 top-0 w-[1440px]" />
    </div>
  );
}

function Frame() {
  return (
    <div className="absolute h-[23.912px] left-[3.69px] top-[8px] w-[31.923px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 31.9231 23.9117">
        <g id="Frame 6">
          <path d={svgPaths.p3cd78c00} fill="var(--fill-0, #EAEAEA)" id="{" />
          <path d={svgPaths.p1fe17672} fill="var(--fill-0, #EAEAEA)" id="B" />
        </g>
      </svg>
    </div>
  );
}

function Frame25() {
  return (
    <div className="absolute content-stretch flex gap-[24px] items-center left-[936px] top-[32px]">
      <div className="relative shrink-0 size-[32px]" data-name="image 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage1} />
      </div>
      <div className="relative shrink-0 size-[32px]" data-name="LI-In-Bug 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-full left-0 max-w-none top-0 w-[117.59%]" src={imgLiInBug1} />
        </div>
      </div>
    </div>
  );
}

function Frame8() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[96px] left-1/2 overflow-clip top-1/2 w-[1024px]">
      <div className="-translate-y-1/2 absolute content-stretch flex gap-[3.692px] items-center left-0 top-1/2 w-[208px]" data-name="mark-logo">
        <div className="bg-[#17171c] overflow-clip relative rounded-[12px] shrink-0 size-[48px]" data-name="ic-logo">
          <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 overflow-clip size-[39.385px] top-1/2" data-name="mark">
            <Frame />
          </div>
        </div>
        <div className="h-[23.914px] relative shrink-0 w-[157.148px]" data-name="racket">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 157.148 23.9138">
            <g id="racket">
              <path d={svgPaths.p27ca7490} fill="#17171C" />
              <path d={svgPaths.p7614780} fill="#17171C" />
              <path d={svgPaths.p30bc51c0} fill="#17171C" />
              <path d={svgPaths.pe7c6900} fill="#17171C" />
              <path d={svgPaths.pbf322c0} fill="#17171C" />
              <path d={svgPaths.pe9e7600} fill="#17171C" />
            </g>
          </svg>
        </div>
      </div>
      <Frame25 />
    </div>
  );
}

function Navbar() {
  return (
    <div className="-translate-x-1/2 absolute h-[96px] left-1/2 top-0 w-[1440px]" data-name="navbar">
      <BgNavbar />
      <Frame8 />
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-start relative shrink-0 text-[#17171c] tracking-[-0.2629px] w-[575px] whitespace-pre-wrap">
      <div className="font-['Montserrat:Bold',sans-serif] font-bold leading-[40px] relative shrink-0 text-[48px] w-full">
        <p className="mb-0">Designed once.</p>
        <p>Licensed forever.</p>
      </div>
      <p className="font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] relative shrink-0 text-[24px] w-full">
        Designers publish complete UI systems.
        <br aria-hidden="true" />
        Companies license them to ship products faster.
      </p>
    </div>
  );
}

function ButtonContentArea() {
  return (
    <div className="bg-[rgba(168,230,207,0)] content-stretch flex items-center justify-center pl-[16px] pr-[300px] py-[16px] relative rounded-[8px] shrink-0" data-name="Button - Content Area">
      <div aria-hidden="true" className="absolute border border-[rgba(23,23,28,0.2)] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[14px] opacity-20 relative shrink-0 text-[#17171c] text-[14px] tracking-[-0.2629px]">YOUR EMAIL</p>
    </div>
  );
}

function TextField() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center py-[6px] relative shrink-0" data-name="text-field">
      <ButtonContentArea />
    </div>
  );
}

function ButtonContentArea1() {
  return (
    <div className="bg-[#f5b700] content-stretch flex items-center justify-center px-[38px] py-[16px] relative rounded-[8px] shrink-0" data-name="Button - Content Area">
      <p className="font-['Montserrat:Medium',sans-serif] font-medium leading-[14px] relative shrink-0 text-[#17171c] text-[14px] tracking-[-0.2629px] w-[108px] whitespace-pre-wrap">JOIN WAITLIST</p>
    </div>
  );
}

function CtaPrimary() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip py-[6px] relative shrink-0" data-name="cta-primary">
      <ButtonContentArea1 />
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <TextField />
      <CtaPrimary />
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0">
      <Frame11 />
      <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[14px] lowercase relative shrink-0 text-[#17171c] text-[14px] tracking-[-0.2629px]">We’ll email you when Bracket goes live. No spam.</p>
    </div>
  );
}

function HeroConent() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0" data-name="hero-conent">
      <Frame10 />
      <Frame9 />
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex gap-[24px] items-center relative shrink-0 w-full">
      <HeroConent />
      <div className="h-[240px] relative rounded-[20px] shrink-0 w-[400px]" data-name="61273222 1">
        <div className="absolute inset-0 overflow-hidden rounded-[20px]">
          <video autoPlay className="absolute h-[100.08%] left-[-3%] max-w-none top-[-0.04%] w-[106.75%]" controlsList="nodownload" loop playsInline>
            <source src="/_videos/v1/a35a8bf8b4ff62d1010c9535a31344ce72871f19" />
          </video>
        </div>
        <div aria-hidden="true" className="absolute border border-black border-solid inset-0 pointer-events-none rounded-[20px]" />
      </div>
    </div>
  );
}

function Frame13() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center relative shrink-0 text-[#17171c] text-center tracking-[-0.2629px]">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[40px] relative shrink-0 text-[36px]">How Bracket works</p>
      <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[20px] relative shrink-0 text-[20px] w-[728px] whitespace-pre-wrap">Publish structured systems or license proven foundations for your product.</p>
    </div>
  );
}

function Frame18() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] items-end leading-[20px] relative shrink-0 text-[#17171c] text-[20px] text-right tracking-[-0.2629px] w-[466px] whitespace-pre-wrap">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold relative shrink-0 w-full">STEP 01:</p>
      <p className="font-['Montserrat:Regular',sans-serif] font-normal relative shrink-0 w-full">Designers build complete UI systems and flows.</p>
    </div>
  );
}

function Frame15() {
  return (
    <div className="content-stretch flex gap-[58px] items-center relative shrink-0">
      <div className="h-[340px] relative rounded-[20px] shrink-0 w-[500px]" data-name="step 1 1">
        <div className="absolute inset-0 overflow-hidden rounded-[20px]">
          <video autoPlay className="absolute h-full left-[-10.41%] max-w-none top-0 w-[124.95%]" controlsList="nodownload" loop playsInline>
            <source src="/_videos/v1/0d978737779e737a85af1d013458a9e774b88bf1" />
          </video>
        </div>
        <div aria-hidden="true" className="absolute border-2 border-[#17171c] border-solid inset-0 pointer-events-none rounded-[20px]" />
      </div>
      <Frame18 />
    </div>
  );
}

function Frame19() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] items-end leading-[20px] relative shrink-0 text-[#17171c] text-[20px] tracking-[-0.2629px] w-[466px] whitespace-pre-wrap">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold relative shrink-0 w-full">STEP 02:</p>
      <p className="font-['Montserrat:Regular',sans-serif] font-normal relative shrink-0 w-full">They publish their design systems on Bracket.</p>
    </div>
  );
}

function Frame16() {
  return (
    <div className="content-stretch flex gap-[58px] items-center relative shrink-0">
      <Frame19 />
      <div className="h-[340px] relative rounded-[20px] shrink-0 w-[500px]" data-name="58592901 1">
        <div className="absolute inset-0 overflow-hidden rounded-[20px]">
          <video autoPlay className="absolute h-full left-[-10.04%] max-w-none top-0 w-[120.89%]" controlsList="nodownload" loop playsInline>
            <source src="/_videos/v1/c59cdf230d70371dc4cb40cb33c9df88cb72ffaa" />
          </video>
        </div>
        <div aria-hidden="true" className="absolute border-2 border-[#17171c] border-solid inset-0 pointer-events-none rounded-[20px]" />
      </div>
    </div>
  );
}

function Frame22() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] items-end leading-[20px] relative shrink-0 text-[#17171c] text-[20px] text-right tracking-[-0.2629px] w-[466px] whitespace-pre-wrap">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold relative shrink-0 w-full">STEP 03:</p>
      <p className="font-['Montserrat:Regular',sans-serif] font-normal relative shrink-0 w-full">Companies license ready-to-use systems to build faster.</p>
    </div>
  );
}

function Frame21() {
  return (
    <div className="content-stretch flex gap-[58px] items-center relative shrink-0">
      <div className="h-[340px] relative rounded-[20px] shrink-0 w-[500px]" data-name="step 1 1">
        <video autoPlay className="absolute max-w-none object-cover rounded-[20px] size-full" controlsList="nodownload" loop playsInline>
          <source src="/_videos/v1/0d978737779e737a85af1d013458a9e774b88bf1" />
        </video>
        <div aria-hidden="true" className="absolute border-2 border-[#17171c] border-solid inset-0 pointer-events-none rounded-[20px]" />
      </div>
      <Frame22 />
    </div>
  );
}

function Frame24() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] items-end leading-[20px] relative shrink-0 text-[#17171c] text-[20px] tracking-[-0.2629px] w-[466px] whitespace-pre-wrap">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold relative shrink-0 w-full">STEP 04:</p>
      <p className="font-['Montserrat:Regular',sans-serif] font-normal relative shrink-0 w-full">Designers earn every time their systems are licensed.</p>
    </div>
  );
}

function Frame23() {
  return (
    <div className="content-stretch flex gap-[58px] items-center relative shrink-0">
      <Frame24 />
      <div className="h-[340px] relative rounded-[20px] shrink-0 w-[500px]" data-name="58592901 1">
        <div className="absolute inset-0 overflow-hidden rounded-[20px]">
          <video autoPlay className="absolute h-full left-[-10.04%] max-w-none top-0 w-[120.89%]" controlsList="nodownload" loop playsInline>
            <source src="/_videos/v1/c59cdf230d70371dc4cb40cb33c9df88cb72ffaa" />
          </video>
        </div>
        <div aria-hidden="true" className="absolute border-2 border-[#17171c] border-solid inset-0 pointer-events-none rounded-[20px]" />
      </div>
    </div>
  );
}

function Frame17() {
  return (
    <div className="content-stretch flex flex-col gap-[36px] items-start relative shrink-0 w-full">
      <Frame15 />
      <Frame16 />
      <Frame21 />
      <Frame23 />
    </div>
  );
}

function Frame20() {
  return (
    <div className="content-stretch flex flex-col gap-[36px] items-center relative shrink-0 w-full">
      <Frame13 />
      <Frame17 />
    </div>
  );
}

function Frame27() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute content-stretch flex flex-col gap-[12px] items-center left-1/2 text-[#17171c] text-center top-1/2 w-[632px] whitespace-pre-wrap">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[36px] relative shrink-0 text-[36px] tracking-[-0.2719px] w-full">Did you know?</p>
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[24px] relative shrink-0 text-[24px] tracking-[-0.2629px] w-full">Design systems usually stay unused after one client.</p>
    </div>
  );
}

function Frame28() {
  return (
    <div className="-translate-x-1/2 absolute h-[8px] left-1/2 top-[180px] w-[52px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 52 8">
        <g id="Frame 45">
          <circle cx="4" cy="4" fill="var(--fill-0, #17171C)" fillOpacity="0.6" id="Ellipse 1" r="4" />
          <circle cx="18" cy="4" fill="var(--fill-0, #17171C)" fillOpacity="0.6" id="Ellipse 2" r="4" />
          <rect fill="var(--fill-0, #F5B700)" height="8" id="Rectangle 66" rx="4" width="24" x="28" />
        </g>
      </svg>
    </div>
  );
}

function Frame26() {
  return (
    <div className="bg-[#f0f0eb] h-[200px] relative rounded-[20px] shrink-0 w-[1024px]">
      <div aria-hidden="true" className="absolute border-2 border-[rgba(23,23,28,0.4)] border-solid inset-0 pointer-events-none rounded-[20px] shadow-[0px_0px_20px_0px_rgba(0,0,0,0.2)]" />
      <Frame27 />
      <Frame28 />
    </div>
  );
}

function MainWebsiteContent() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[64px] items-start left-[208px] top-[144px] w-[1024px]" data-name="main-website-content">
      <Frame12 />
      <Frame20 />
      <Frame26 />
    </div>
  );
}

function Frame7() {
  return (
    <div className="absolute h-[18.164px] left-[2.8px] top-[6.08px] w-[24.249px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.2493 18.1637">
        <g id="Frame 6">
          <path d={svgPaths.p182da200} fill="var(--fill-0, white)" id="{" />
          <path d={svgPaths.p3a53f700} fill="var(--fill-0, white)" id="B" />
        </g>
      </svg>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-0 top-[20px]">
      <p className="-translate-x-1/2 absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] left-[26px] text-[#17171c] text-[9.115px] text-center top-[66px] tracking-[-0.4065px]">© BRACKET</p>
      <div className="absolute bg-black left-[8px] overflow-clip rounded-[12px] size-[36px] top-[20px]" data-name="ic-logo">
        <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 overflow-clip size-[29.917px] top-1/2" data-name="mark">
          <Frame7 />
        </div>
      </div>
    </div>
  );
}

function Frame29() {
  return (
    <div className="absolute content-stretch flex gap-[24px] items-center left-[936px] top-[32px]">
      <div className="relative shrink-0 size-[32px]" data-name="image 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage1} />
      </div>
      <div className="relative shrink-0 size-[32px]" data-name="LI-In-Bug 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-full left-0 max-w-none top-0 w-[117.59%]" src={imgLiInBug1} />
        </div>
      </div>
    </div>
  );
}

function Frame14() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[104px] left-1/2 overflow-clip top-[calc(50%+1172px)] w-[1024px]">
      <Group1 />
      <Frame29 />
    </div>
  );
}

function Footer() {
  return (
    <div className="absolute contents left-0 top-[2344px]" data-name="footer">
      <div className="absolute bg-[rgba(217,217,217,0)] h-[104px] left-0 opacity-30 top-[2344px] w-[1440px]">
        <div aria-hidden="true" className="absolute border-[#17171c] border-solid border-t inset-[-0.5px_0_0_0] pointer-events-none" />
      </div>
      <Frame14 />
    </div>
  );
}

export default function LandingPageWaitlist() {
  return (
    <div className="bg-white relative size-full" data-name="landing-page-waitlist">
      <BgSurface />
      <Navbar />
      <MainWebsiteContent />
      <Footer />
    </div>
  );
}