import svgPaths from "./svg-te6luaupxq";
import imgImage1 from "figma:asset/5f67aa4bdf1c70dc605145f809e72f8f90a4ea03.png";
import imgLiInBug1 from "figma:asset/eb0a7e1284e631d80c3225c0e2d6c7af931de535.png";

function Group() {
  return (
    <div className="absolute inset-[29.72%_2.46%]" data-name="Group">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 78.9123 33.6648">
        <g id="Group">
          <path d={svgPaths.p54ae700} fill="var(--fill-0, #F5B700)" id="Vector" />
          <path d={svgPaths.p2cea7780} fill="var(--fill-0, #EAEAEA)" id="Vector_2" />
          <path d={svgPaths.p16f81900} fill="var(--fill-0, #0F0F12)" id="Vector_3" />
          <path d={svgPaths.p8068e00} fill="var(--fill-0, #EAEAEA)" id="Vector_4" />
          <path d={svgPaths.p203e0400} fill="var(--fill-0, #EAEAEA)" id="Vector_5" />
          <path d={svgPaths.p18564670} fill="var(--fill-0, #EAEAEA)" id="Vector_6" />
          <path d={svgPaths.p7ff3030} fill="var(--fill-0, #0F0F12)" id="Vector_7" />
          <path d={svgPaths.p1200e780} fill="var(--fill-0, #EAEAEA)" id="Vector_8" />
          <path d={svgPaths.p22677c00} fill="var(--fill-0, #EAEAEA)" id="Vector_9" />
          <path d={svgPaths.p8f3bcb0} fill="var(--fill-0, #EAEAEA)" id="Vector_10" />
          <path d={svgPaths.p32906b80} fill="var(--fill-0, #EAEAEA)" id="Vector_11" />
          <path d={svgPaths.p24b3fd80} fill="var(--fill-0, #EAEAEA)" id="Vector_12" />
          <path d={svgPaths.peaa9c00} fill="var(--fill-0, #0F0F12)" id="Vector_13" />
          <path d={svgPaths.p2428e200} fill="var(--fill-0, #EAEAEA)" id="Vector_14" />
          <path d={svgPaths.p3f52ad80} fill="var(--fill-0, #EAEAEA)" id="Vector_15" />
          <path d={svgPaths.p17863d40} fill="var(--fill-0, #EAEAEA)" id="Vector_16" />
          <path d={svgPaths.p103526f0} fill="var(--fill-0, #EAEAEA)" id="Vector_17" />
          <path d={svgPaths.p2807a000} fill="var(--fill-0, #EAEAEA)" id="Vector_18" />
          <path d={svgPaths.p1b74bd00} fill="var(--fill-0, #EAEAEA)" id="Vector_19" />
          <path d={svgPaths.p24c43480} fill="var(--fill-0, #EAEAEA)" id="Vector_20" />
          <path d={svgPaths.p1226af00} fill="var(--fill-0, #EAEAEA)" id="Vector_21" />
          <path d={svgPaths.p1f74f7f0} fill="var(--fill-0, #EAEAEA)" id="Vector_22" />
          <path d={svgPaths.p1c4fbd80} fill="var(--fill-0, #EAEAEA)" id="Vector_23" />
          <path d={svgPaths.p30c9b280} fill="var(--fill-0, #EAEAEA)" id="Vector_24" />
          <path d={svgPaths.p182ab00} fill="var(--fill-0, #EAEAEA)" id="Vector_25" />
          <path d={svgPaths.p2f5c4a00} fill="var(--fill-0, #EAEAEA)" id="Vector_26" />
          <path d={svgPaths.p1572a900} fill="var(--fill-0, #EAEAEA)" id="Vector_27" />
          <path d={svgPaths.p388cec00} fill="var(--fill-0, #EAEAEA)" id="Vector_28" />
          <path d={svgPaths.p1f88d400} fill="var(--fill-0, #EAEAEA)" id="Vector_29" />
          <path d={svgPaths.p1df31c70} fill="var(--fill-0, #F5B700)" id="Vector_30" />
          <path d={svgPaths.pf2ac840} fill="var(--fill-0, #9B8500)" id="Vector_31" />
          <path d={svgPaths.p2554e7e0} fill="var(--fill-0, #F5B700)" id="Vector_32" />
          <path d={svgPaths.p43eb300} fill="var(--fill-0, #F5B700)" id="Vector_33" />
          <path d={svgPaths.p38e66800} fill="var(--fill-0, #9B8500)" id="Vector_34" />
          <path d={svgPaths.p12e0da80} fill="var(--fill-0, #9B8500)" id="Vector_35" />
          <path d={svgPaths.p32373e00} fill="var(--fill-0, #F5B700)" id="Vector_36" />
          <path d={svgPaths.p2b314180} fill="var(--fill-0, #F5B700)" id="Vector_37" />
          <path d={svgPaths.pc24cf80} fill="var(--fill-0, #9B8500)" id="Vector_38" />
          <path d={svgPaths.p56eec80} fill="var(--fill-0, #F5B700)" id="Vector_39" />
          <path d={svgPaths.pa656300} fill="var(--fill-0, #9B8500)" id="Vector_40" />
          <path d={svgPaths.p29f57900} fill="var(--fill-0, #F5B700)" id="Vector_41" />
          <path d={svgPaths.p3d0ad680} fill="var(--fill-0, #9B8500)" id="Vector_42" />
          <path d={svgPaths.pb991f2} fill="var(--fill-0, #9B8500)" id="Vector_43" />
          <path d={svgPaths.p735a700} fill="var(--fill-0, #F5B700)" id="Vector_44" />
          <path d={svgPaths.p24760980} fill="var(--fill-0, #F5B700)" id="Vector_45" />
          <path d={svgPaths.p20e2e980} fill="var(--fill-0, #F5B700)" id="Vector_46" />
          <path d={svgPaths.p1a6940c0} fill="var(--fill-0, #F5B700)" id="Vector_47" />
          <path d={svgPaths.p39477700} fill="var(--fill-0, #F5B700)" id="Vector_48" />
          <path d={svgPaths.p28271e30} fill="var(--fill-0, #F5B700)" id="Vector_49" />
          <path d={svgPaths.p1a633a00} fill="var(--fill-0, #F5B700)" id="Vector_50" />
          <path d={svgPaths.p3524cb0} fill="var(--fill-0, #F5B700)" id="Vector_51" />
          <path d={svgPaths.p67b4100} fill="var(--fill-0, #F5B700)" id="Vector_52" />
          <path d={svgPaths.p3c236280} fill="var(--fill-0, #F5B700)" id="Vector_53" />
          <path d={svgPaths.p650dc00} fill="var(--fill-0, #9B8500)" id="Vector_54" />
          <path d={svgPaths.p3fc52e00} fill="var(--fill-0, #F5B700)" id="Vector_55" />
          <path d={svgPaths.p254efc80} fill="var(--fill-0, #F5B700)" id="Vector_56" />
          <path d={svgPaths.p344ab080} fill="var(--fill-0, #F5B700)" id="Vector_57" />
          <path d={svgPaths.p9fcd1f8} fill="var(--fill-0, #F5B700)" id="Vector_58" />
          <path d={svgPaths.p4713680} fill="var(--fill-0, #9B8500)" id="Vector_59" />
          <path d={svgPaths.pf2532f0} fill="var(--fill-0, #F5B700)" id="Vector_60" />
          <path d={svgPaths.p2e4a3200} fill="var(--fill-0, #F5B700)" id="Vector_61" />
          <path d={svgPaths.p29afc800} fill="var(--fill-0, #F5B700)" id="Vector_62" />
          <path d={svgPaths.p1260ca40} fill="var(--fill-0, #9B8500)" id="Vector_63" />
          <path d={svgPaths.p1c338e00} fill="var(--fill-0, #9B8500)" id="Vector_64" />
          <path d={svgPaths.p1c9bfac0} fill="var(--fill-0, #F5B700)" id="Vector_65" />
          <path d={svgPaths.p37fe80e0} fill="var(--fill-0, #0F0F12)" id="Vector_66" />
          <path d={svgPaths.p2f7f1100} fill="var(--fill-0, #0F0F12)" id="Vector_67" />
          <path d={svgPaths.pc2c980} fill="var(--fill-0, #0F0F12)" id="Vector_68" />
          <path d={svgPaths.p206d8900} fill="var(--fill-0, #0F0F12)" id="Vector_69" />
          <path d={svgPaths.p2cb00700} fill="var(--fill-0, #0F0F12)" id="Vector_70" />
          <path d={svgPaths.p13fa9000} fill="var(--fill-0, #F5B700)" id="Vector_71" />
          <path d={svgPaths.p3d9ae000} fill="var(--fill-0, #F5B700)" id="Vector_72" />
          <path d={svgPaths.p2ab6f002} fill="var(--fill-0, #F5B700)" id="Vector_73" />
          <path d={svgPaths.p2b61ac00} fill="var(--fill-0, #F5B700)" id="Vector_74" />
          <path d={svgPaths.p398f3a80} fill="var(--fill-0, #0F0F12)" id="Vector_75" />
          <path d={svgPaths.p28540e00} fill="var(--fill-0, #F5B700)" id="Vector_76" />
          <path d={svgPaths.p143ccbf0} fill="var(--fill-0, #0F0F12)" id="Vector_77" />
          <path d={svgPaths.p4a38300} fill="var(--fill-0, #0F0F12)" id="Vector_78" />
          <path d={svgPaths.p3b6a3e80} fill="var(--fill-0, #0F0F12)" id="Vector_79" />
          <path d={svgPaths.p23345000} fill="var(--fill-0, #EAEAEA)" id="Vector_80" />
          <path d={svgPaths.p49df0f0} fill="var(--fill-0, #0F0F12)" id="Vector_81" />
          <path d={svgPaths.p7cdcb80} fill="var(--fill-0, #EAEAEA)" id="Vector_82" />
          <path d={svgPaths.p13e25f00} fill="var(--fill-0, #0F0F12)" id="Vector_83" />
          <path d={svgPaths.p78862c0} fill="var(--fill-0, #0F0F12)" id="Vector_84" />
          <path d={svgPaths.pd6d7700} fill="var(--fill-0, #EAEAEA)" id="Vector_85" />
          <path d={svgPaths.p25a66900} fill="var(--fill-0, #0F0F12)" id="Vector_86" />
          <path d={svgPaths.p3ad17300} fill="var(--fill-0, #EAEAEA)" id="Vector_87" />
          <path d={svgPaths.pd140700} fill="var(--fill-0, #0F0F12)" id="Vector_88" />
          <path d={svgPaths.pf0e2000} fill="var(--fill-0, #EAEAEA)" id="Vector_89" />
          <path d={svgPaths.p3b211080} fill="var(--fill-0, #0F0F12)" id="Vector_90" />
          <path d={svgPaths.p25788000} fill="var(--fill-0, #EAEAEA)" id="Vector_91" />
          <path d={svgPaths.p229a6040} fill="var(--fill-0, #EAEAEA)" id="Vector_92" />
          <path d={svgPaths.pe1d2140} fill="var(--fill-0, #0F0F12)" id="Vector_93" />
          <path d={svgPaths.p1e7d4100} fill="var(--fill-0, #EAEAEA)" id="Vector_94" />
          <path d={svgPaths.p14b49d00} fill="var(--fill-0, #0F0F12)" id="Vector_95" />
          <path d={svgPaths.p1b729000} fill="var(--fill-0, #F5B700)" id="Vector_96" />
          <path d={svgPaths.p26b1b900} fill="var(--fill-0, #EAEAEA)" id="Vector_97" />
          <path d={svgPaths.p3de5380} fill="var(--fill-0, #0F0F12)" id="Vector_98" />
          <path d={svgPaths.p2fffd380} fill="var(--fill-0, #F5B700)" id="Vector_99" />
          <path d={svgPaths.p144c1d80} fill="var(--fill-0, #EAEAEA)" id="Vector_100" />
          <path d={svgPaths.p333e6bf0} fill="var(--fill-0, #0F0F12)" id="Vector_101" />
          <path d={svgPaths.p162b7440} fill="var(--fill-0, #F5B700)" id="Vector_102" />
          <path d={svgPaths.p39512b80} fill="var(--fill-0, #F5B700)" id="Vector_103" />
          <path d={svgPaths.p20c15e40} fill="var(--fill-0, #EAEAEA)" id="Vector_104" />
          <path d={svgPaths.p1bc15e80} fill="var(--fill-0, #F5B700)" id="Vector_105" />
          <path d={svgPaths.p15e8ce00} fill="var(--fill-0, #F5B700)" id="Vector_106" />
          <path d={svgPaths.pa5bec80} fill="var(--fill-0, #0F0F12)" id="Vector_107" />
          <path d={svgPaths.p13eec900} fill="var(--fill-0, #9B8500)" id="Vector_108" />
          <path d={svgPaths.p35b12700} fill="var(--fill-0, #F5B700)" id="Vector_109" />
          <path d={svgPaths.p181fcb30} fill="var(--fill-0, #F5B700)" id="Vector_110" />
          <path d={svgPaths.p2c310d00} fill="var(--fill-0, #F5B700)" id="Vector_111" />
          <path d={svgPaths.p19971180} fill="var(--fill-0, #F5B700)" id="Vector_112" />
          <path d={svgPaths.p211bf280} fill="var(--fill-0, #0F0F12)" id="Vector_113" />
          <path d={svgPaths.p3b96780} fill="var(--fill-0, #F5B700)" id="Vector_114" />
          <path d={svgPaths.p2bc156f0} fill="var(--fill-0, #F5B700)" id="Vector_115" />
          <path d={svgPaths.p23b91a00} fill="var(--fill-0, #9B8500)" id="Vector_116" />
          <path d={svgPaths.p14969780} fill="var(--fill-0, #F5B700)" id="Vector_117" />
          <path d={svgPaths.p3fa74900} fill="var(--fill-0, #F5B700)" id="Vector_118" />
          <path d={svgPaths.p29e55580} fill="var(--fill-0, #0F0F12)" id="Vector_119" />
          <path d={svgPaths.p325f7d00} fill="var(--fill-0, #F5B700)" id="Vector_120" />
          <path d={svgPaths.p18dfdf00} fill="var(--fill-0, #F5B700)" id="Vector_121" />
          <path d={svgPaths.p2d14bc00} fill="var(--fill-0, #F5B700)" id="Vector_122" />
          <path d={svgPaths.p7ecda00} fill="var(--fill-0, #0F0F12)" id="Vector_123" />
          <path d={svgPaths.p21ababf0} fill="var(--fill-0, #0F0F12)" id="Vector_124" />
          <path d={svgPaths.p2e066480} fill="var(--fill-0, #F5B700)" id="Vector_125" />
          <path d={svgPaths.p2699ac80} fill="var(--fill-0, #F5B700)" id="Vector_126" />
          <path d={svgPaths.pc835c00} fill="var(--fill-0, #F5B700)" id="Vector_127" />
          <path d={svgPaths.p7993400} fill="var(--fill-0, #F5B700)" id="Vector_128" />
          <path d={svgPaths.p2e163300} fill="var(--fill-0, #F5B700)" id="Vector_129" />
          <path d={svgPaths.p87cfd00} fill="var(--fill-0, #0F0F12)" id="Vector_130" />
          <path d={svgPaths.p244c3c00} fill="var(--fill-0, #F5B700)" id="Vector_131" />
          <path d={svgPaths.p3a319000} fill="var(--fill-0, #F5B700)" id="Vector_132" />
          <path d={svgPaths.p4d7c500} fill="var(--fill-0, #F5B700)" id="Vector_133" />
          <path d={svgPaths.p1d3b0200} fill="var(--fill-0, #F5B700)" id="Vector_134" />
          <path d={svgPaths.p86dbf00} fill="var(--fill-0, #F5B700)" id="Vector_135" />
          <path d={svgPaths.p3f33e600} fill="var(--fill-0, #F5B700)" id="Vector_136" />
          <path d={svgPaths.p9527f00} fill="var(--fill-0, #F5B700)" id="Vector_137" />
          <path d={svgPaths.p9d75200} fill="var(--fill-0, #9B8500)" id="Vector_138" />
          <path d={svgPaths.p21db7300} fill="var(--fill-0, #0F0F12)" id="Vector_139" />
          <path d={svgPaths.p23f82d00} fill="var(--fill-0, #0F0F12)" id="Vector_140" />
          <path d={svgPaths.pa816800} fill="var(--fill-0, #F5B700)" id="Vector_141" />
          <path d={svgPaths.p12015280} fill="var(--fill-0, #F5B700)" id="Vector_142" />
          <path d={svgPaths.p9c8aa80} fill="var(--fill-0, #F5B700)" id="Vector_143" />
          <path d={svgPaths.p15153880} fill="var(--fill-0, #F5B700)" id="Vector_144" />
          <path d={svgPaths.pa72ca00} fill="var(--fill-0, #9B8500)" id="Vector_145" />
          <path d={svgPaths.p2af0f980} fill="var(--fill-0, #9B8500)" id="Vector_146" />
          <path d={svgPaths.pdd22080} fill="var(--fill-0, #9B8500)" id="Vector_147" />
          <path d={svgPaths.p8b87370} fill="var(--fill-0, #9B8500)" id="Vector_148" />
          <path d={svgPaths.p1c306b00} fill="var(--fill-0, #9B8500)" id="Vector_149" />
          <path d={svgPaths.p21b66180} fill="var(--fill-0, #0F0F12)" id="Vector_150" />
          <path d={svgPaths.p3bcf5790} fill="var(--fill-0, #9B8500)" id="Vector_151" />
          <path d={svgPaths.peeef000} fill="var(--fill-0, #0F0F12)" id="Vector_152" />
          <path d={svgPaths.p15ddfa00} fill="var(--fill-0, #9B8500)" id="Vector_153" />
          <path d={svgPaths.p3d15800} fill="var(--fill-0, #9B8500)" id="Vector_154" />
          <path d={svgPaths.p16cbf300} fill="var(--fill-0, #0F0F12)" id="Vector_155" />
          <path d={svgPaths.p2ace7500} fill="var(--fill-0, #0F0F12)" id="Vector_156" />
          <path d={svgPaths.pf2f7100} fill="var(--fill-0, #F5B700)" id="Vector_157" />
          <path d={svgPaths.p20adfec0} fill="var(--fill-0, #F5B700)" id="Vector_158" />
          <path d={svgPaths.p1671dc40} fill="var(--fill-0, #F5B700)" id="Vector_159" />
          <path d={svgPaths.p36d8e780} fill="var(--fill-0, #F5B700)" id="Vector_160" />
          <path d={svgPaths.p3e08ae00} fill="var(--fill-0, #F5B700)" id="Vector_161" />
          <path d={svgPaths.p9625df0} fill="var(--fill-0, #F5B700)" id="Vector_162" />
          <path d={svgPaths.pe573f80} fill="var(--fill-0, #F5B700)" id="Vector_163" />
          <path d={svgPaths.pfb6f900} fill="var(--fill-0, #F5B700)" id="Vector_164" />
          <path d={svgPaths.pe113d00} fill="var(--fill-0, #F5B700)" id="Vector_165" />
          <path d={svgPaths.p35a67c80} fill="var(--fill-0, #0F0F12)" id="Vector_166" />
          <path d={svgPaths.peb49900} fill="var(--fill-0, #0F0F12)" id="Vector_167" />
          <path d={svgPaths.p34c41b50} fill="var(--fill-0, #0F0F12)" id="Vector_168" />
          <path d={svgPaths.p12790000} fill="var(--fill-0, #0F0F12)" id="Vector_169" />
          <path d={svgPaths.p19a10700} fill="var(--fill-0, #F5B700)" id="Vector_170" />
          <path d={svgPaths.p19b84600} fill="var(--fill-0, #F5B700)" id="Vector_171" />
          <path d={svgPaths.p1c8a580} fill="var(--fill-0, #F5B700)" id="Vector_172" />
          <path d={svgPaths.p37e9bf00} fill="var(--fill-0, #F5B700)" id="Vector_173" />
          <path d={svgPaths.p868cc00} fill="var(--fill-0, #F5B700)" id="Vector_174" />
          <path d={svgPaths.p246b6700} fill="var(--fill-0, #F5B700)" id="Vector_175" />
          <path d={svgPaths.p1c416200} fill="var(--fill-0, #9B8500)" id="Vector_176" />
          <path d={svgPaths.p2bef6e00} fill="var(--fill-0, #0F0F12)" id="Vector_177" />
          <path d={svgPaths.p2a05d300} fill="var(--fill-0, #0F0F12)" id="Vector_178" />
          <path d={svgPaths.p1481fc00} fill="var(--fill-0, #F5B700)" id="Vector_179" />
          <path d={svgPaths.p1eb1f100} fill="var(--fill-0, #F5B700)" id="Vector_180" />
          <path d={svgPaths.p3be5980} fill="var(--fill-0, #0F0F12)" id="Vector_181" />
          <path d={svgPaths.p2a397a00} fill="var(--fill-0, #9B8500)" id="Vector_182" />
          <path d={svgPaths.p7d62700} fill="var(--fill-0, #9B8500)" id="Vector_183" />
          <path d={svgPaths.p1e4e8500} fill="var(--fill-0, #9B8500)" id="Vector_184" />
          <path d={svgPaths.p5026a00} fill="var(--fill-0, #9B8500)" id="Vector_185" />
          <path d={svgPaths.p22f3df00} fill="var(--fill-0, #9B8500)" id="Vector_186" />
          <path d={svgPaths.p2e7a0600} fill="var(--fill-0, #F5B700)" id="Vector_187" />
          <path d={svgPaths.p14849c00} fill="var(--fill-0, #0F0F12)" id="Vector_188" />
          <path d={svgPaths.p3df37300} fill="var(--fill-0, #0F0F12)" id="Vector_189" />
          <path d={svgPaths.p82d2700} fill="var(--fill-0, #0F0F12)" id="Vector_190" />
          <path d={svgPaths.p3a678280} fill="var(--fill-0, #0F0F12)" id="Vector_191" />
          <path d={svgPaths.p3acb8870} fill="var(--fill-0, #0F0F12)" id="Vector_192" />
          <path d={svgPaths.p3df86f00} fill="var(--fill-0, #0F0F12)" id="Vector_193" />
          <path d={svgPaths.p37e6d500} fill="var(--fill-0, #0F0F12)" id="Vector_194" />
          <path d={svgPaths.p34eddd00} fill="var(--fill-0, #0F0F12)" id="Vector_195" />
          <path d={svgPaths.p365e5c80} fill="var(--fill-0, #0F0F12)" id="Vector_196" />
          <path d={svgPaths.p1b2c0980} fill="var(--fill-0, #0F0F12)" id="Vector_197" />
          <path d={svgPaths.p36fc8400} fill="var(--fill-0, #0F0F12)" id="Vector_198" />
          <path d={svgPaths.pbf7c880} fill="var(--fill-0, #0F0F12)" id="Vector_199" />
          <path d={svgPaths.p4c65700} fill="var(--fill-0, #0F0F12)" id="Vector_200" />
          <path d={svgPaths.p249adb00} fill="var(--fill-0, #0F0F12)" id="Vector_201" />
          <path d={svgPaths.p16676870} fill="var(--fill-0, #0F0F12)" id="Vector_202" />
          <path d={svgPaths.p2ceb3b00} fill="var(--fill-0, #0F0F12)" id="Vector_203" />
          <path d={svgPaths.p1e196e00} fill="var(--fill-0, #0F0F12)" id="Vector_204" />
          <path d={svgPaths.p309cf000} fill="var(--fill-0, #0F0F12)" id="Vector_205" />
          <path d={svgPaths.p1fe31870} fill="var(--fill-0, #0F0F12)" id="Vector_206" />
          <path d={svgPaths.p1fca6400} fill="var(--fill-0, #0F0F12)" id="Vector_207" />
          <path d={svgPaths.p15d54070} fill="var(--fill-0, #0F0F12)" id="Vector_208" />
          <path d={svgPaths.p2a895800} fill="var(--fill-0, #0F0F12)" id="Vector_209" />
          <path d={svgPaths.p35bce00} fill="var(--fill-0, #0F0F12)" id="Vector_210" />
          <path d={svgPaths.p1db0af80} fill="var(--fill-0, #0F0F12)" id="Vector_211" />
          <path d={svgPaths.p2be778c0} fill="var(--fill-0, #0F0F12)" id="Vector_212" />
          <path d={svgPaths.p3cc7c600} fill="var(--fill-0, #0F0F12)" id="Vector_213" />
          <path d={svgPaths.p21f3f80} fill="var(--fill-0, #0F0F12)" id="Vector_214" />
          <path d={svgPaths.p3a358c80} fill="var(--fill-0, #0F0F12)" id="Vector_215" />
          <path d={svgPaths.p40e4a00} fill="var(--fill-0, #0F0F12)" id="Vector_216" />
          <path d={svgPaths.p3626ae80} fill="var(--fill-0, #0F0F12)" id="Vector_217" />
          <path d={svgPaths.p3bbc3800} fill="var(--fill-0, #0F0F12)" id="Vector_218" />
          <path d={svgPaths.p656c000} fill="var(--fill-0, #0F0F12)" id="Vector_219" />
          <path d={svgPaths.p2232c470} fill="var(--fill-0, #0F0F12)" id="Vector_220" />
          <path d={svgPaths.p14c0c2f0} fill="var(--fill-0, #0F0F12)" id="Vector_221" />
          <path d={svgPaths.p26516c00} fill="var(--fill-0, #0F0F12)" id="Vector_222" />
          <path d={svgPaths.pfb42800} fill="var(--fill-0, #0F0F12)" id="Vector_223" />
          <path d={svgPaths.p20ac0100} fill="var(--fill-0, #0F0F12)" id="Vector_224" />
          <path d={svgPaths.p34673a00} fill="var(--fill-0, #0F0F12)" id="Vector_225" />
          <path d={svgPaths.p1f356900} fill="var(--fill-0, #0F0F12)" id="Vector_226" />
          <path d={svgPaths.p131c6d00} fill="var(--fill-0, #0F0F12)" id="Vector_227" />
          <path d={svgPaths.pdb99800} fill="var(--fill-0, #0F0F12)" id="Vector_228" />
          <path d={svgPaths.p92d7480} fill="var(--fill-0, #0F0F12)" id="Vector_229" />
          <path d={svgPaths.p2723a200} fill="var(--fill-0, #0F0F12)" id="Vector_230" />
          <path d={svgPaths.p33d42a00} fill="var(--fill-0, #0F0F12)" id="Vector_231" />
          <path d={svgPaths.p399bc700} fill="var(--fill-0, #0F0F12)" id="Vector_232" />
          <path d={svgPaths.p3d84e000} fill="var(--fill-0, #0F0F12)" id="Vector_233" />
          <path d={svgPaths.p15232000} fill="var(--fill-0, #0F0F12)" id="Vector_234" />
          <path d={svgPaths.p1cfff380} fill="var(--fill-0, #0F0F12)" id="Vector_235" />
          <path d={svgPaths.p17184e00} fill="var(--fill-0, #0F0F12)" id="Vector_236" />
          <path d={svgPaths.p3f163b80} fill="var(--fill-0, #0F0F12)" id="Vector_237" />
          <path d={svgPaths.p193989c0} fill="var(--fill-0, #0F0F12)" id="Vector_238" />
          <path d={svgPaths.p10d43600} fill="var(--fill-0, #0F0F12)" id="Vector_239" />
          <path d={svgPaths.pe664e80} fill="var(--fill-0, #0F0F12)" id="Vector_240" />
          <path d={svgPaths.p23665580} fill="var(--fill-0, #F5B700)" id="Vector_241" />
          <path d={svgPaths.pdf3c700} fill="var(--fill-0, #0F0F12)" id="Vector_242" />
          <path d={svgPaths.p34e7200} fill="var(--fill-0, #0F0F12)" id="Vector_243" />
          <path d={svgPaths.p296acb00} fill="var(--fill-0, #0F0F12)" id="Vector_244" />
          <path d={svgPaths.p2a1ace00} fill="var(--fill-0, #EAEAEA)" id="Vector_245" />
          <path d={svgPaths.p20bfcf00} fill="var(--fill-0, #EAEAEA)" id="Vector_246" />
          <path d={svgPaths.p37ec6400} fill="var(--fill-0, #0F0F12)" id="Vector_247" />
          <path d={svgPaths.p14f6de00} fill="var(--fill-0, #0F0F12)" id="Vector_248" />
          <path d={svgPaths.p307ea7f0} fill="var(--fill-0, #0F0F12)" id="Vector_249" />
          <path d={svgPaths.p25242bc0} fill="var(--fill-0, #0F0F12)" id="Vector_250" />
          <path d={svgPaths.p15eb900} fill="var(--fill-0, #0F0F12)" id="Vector_251" />
          <path d={svgPaths.p135a900} fill="var(--fill-0, #0F0F12)" id="Vector_252" />
          <path d={svgPaths.p29b37900} fill="var(--fill-0, #0F0F12)" id="Vector_253" />
          <path d={svgPaths.p210b9cc0} fill="var(--fill-0, #0F0F12)" id="Vector_254" />
          <path d={svgPaths.p19b77f80} fill="var(--fill-0, #0F0F12)" id="Vector_255" />
          <path d={svgPaths.p2d0c2700} fill="var(--fill-0, #0F0F12)" id="Vector_256" />
          <path d={svgPaths.p30029200} fill="var(--fill-0, #0F0F12)" id="Vector_257" />
          <path d={svgPaths.p1c50ff00} fill="var(--fill-0, #0F0F12)" id="Vector_258" />
          <path d={svgPaths.p3eb75740} fill="var(--fill-0, #0F0F12)" id="Vector_259" />
          <path d={svgPaths.p3dc5a400} fill="var(--fill-0, #0F0F12)" id="Vector_260" />
          <path d={svgPaths.pba30200} fill="var(--fill-0, #0F0F12)" id="Vector_261" />
          <path d={svgPaths.p25bde80} fill="var(--fill-0, #0F0F12)" id="Vector_262" />
          <path d={svgPaths.p1d9a0c00} fill="var(--fill-0, #0F0F12)" id="Vector_263" />
          <path d={svgPaths.p2a373800} fill="var(--fill-0, #0F0F12)" id="Vector_264" />
          <path d={svgPaths.p2f7b2300} fill="var(--fill-0, #0F0F12)" id="Vector_265" />
          <path d={svgPaths.p3ec3f100} fill="var(--fill-0, #9B8500)" id="Vector_266" />
          <path d={svgPaths.p39056100} fill="var(--fill-0, #F5B700)" id="Vector_267" />
          <path d={svgPaths.p288eb980} fill="var(--fill-0, #9B8500)" id="Vector_268" />
          <path d={svgPaths.p1e3ccf80} fill="var(--fill-0, #0F0F12)" id="Vector_269" />
          <path d={svgPaths.p2849af00} fill="var(--fill-0, #0F0F12)" id="Vector_270" />
          <path d={svgPaths.pc46f780} fill="var(--fill-0, #0F0F12)" id="Vector_271" />
          <path d={svgPaths.p613d080} fill="var(--fill-0, #EAEAEA)" id="Vector_272" />
          <path d={svgPaths.p27bfb500} fill="var(--fill-0, #EAEAEA)" id="Vector_273" />
          <path d={svgPaths.p56737f0} fill="var(--fill-0, #EAEAEA)" id="Vector_274" />
          <path d={svgPaths.p2b23f580} fill="var(--fill-0, #EAEAEA)" id="Vector_275" />
          <path d={svgPaths.pbfe2200} fill="var(--fill-0, #0F0F12)" id="Vector_276" />
          <path d={svgPaths.p2a209680} fill="var(--fill-0, #0F0F12)" id="Vector_277" />
          <path d={svgPaths.p3467600} fill="var(--fill-0, #EAEAEA)" id="Vector_278" />
          <path d={svgPaths.p2f94e540} fill="var(--fill-0, #EAEAEA)" id="Vector_279" />
          <path d={svgPaths.p2c141a00} fill="var(--fill-0, #EAEAEA)" id="Vector_280" />
          <path d={svgPaths.p3fd65900} fill="var(--fill-0, #EAEAEA)" id="Vector_281" />
          <path d={svgPaths.p33ac300} fill="var(--fill-0, #EAEAEA)" id="Vector_282" />
          <path d={svgPaths.pce02680} fill="var(--fill-0, #F5B700)" id="Vector_283" />
          <path d={svgPaths.p2f02b400} fill="var(--fill-0, #9B8500)" id="Vector_284" />
          <path d={svgPaths.p36977d00} fill="var(--fill-0, #F5B700)" id="Vector_285" />
          <path d={svgPaths.pce71800} fill="var(--fill-0, #9B8500)" id="Vector_286" />
          <path d={svgPaths.p3bf9df00} fill="var(--fill-0, #F5B700)" id="Vector_287" />
          <path d={svgPaths.p3b0f1880} fill="var(--fill-0, #F5B700)" id="Vector_288" />
          <path d={svgPaths.p27c17880} fill="var(--fill-0, #F5B700)" id="Vector_289" />
          <path d={svgPaths.p2ed8c280} fill="var(--fill-0, #0F0F12)" id="Vector_290" />
          <path d={svgPaths.p22f0e480} fill="var(--fill-0, #EAEAEA)" id="Vector_291" />
          <path d={svgPaths.p3f049f00} fill="var(--fill-0, #EAEAEA)" id="Vector_292" />
          <path d={svgPaths.p307e9500} fill="var(--fill-0, #0F0F12)" id="Vector_293" />
          <path d={svgPaths.p29329b00} fill="var(--fill-0, #EAEAEA)" id="Vector_294" />
          <path d={svgPaths.p138faf80} fill="var(--fill-0, #EAEAEA)" id="Vector_295" />
          <path d={svgPaths.p30a63280} fill="var(--fill-0, #F5B700)" id="Vector_296" />
          <path d={svgPaths.p16684000} fill="var(--fill-0, #F5B700)" id="Vector_297" />
          <path d={svgPaths.p21118ef0} fill="var(--fill-0, #F5B700)" id="Vector_298" />
          <path d={svgPaths.p2a4b1480} fill="var(--fill-0, #F5B700)" id="Vector_299" />
          <path d={svgPaths.p2fa71200} fill="var(--fill-0, #F5B700)" id="Vector_300" />
          <path d={svgPaths.p5424500} fill="var(--fill-0, #F5B700)" id="Vector_301" />
          <path d={svgPaths.p1ae50680} fill="var(--fill-0, #F5B700)" id="Vector_302" />
          <path d={svgPaths.pe6ae900} fill="var(--fill-0, #0F0F12)" id="Vector_303" />
          <path d={svgPaths.p245d8100} fill="var(--fill-0, #0F0F12)" id="Vector_304" />
          <path d={svgPaths.p2ba2c480} fill="var(--fill-0, #EAEAEA)" id="Vector_305" />
          <path d={svgPaths.p12b0f3d0} fill="var(--fill-0, #EAEAEA)" id="Vector_306" />
          <path d={svgPaths.p14380d00} fill="var(--fill-0, #EAEAEA)" id="Vector_307" />
          <path d={svgPaths.p15225700} fill="var(--fill-0, #F5B700)" id="Vector_308" />
          <path d={svgPaths.p2b712800} fill="var(--fill-0, #0F0F12)" id="Vector_309" />
          <path d={svgPaths.pba5ca00} fill="var(--fill-0, #0F0F12)" id="Vector_310" />
          <path d={svgPaths.p6fa3100} fill="var(--fill-0, #F5B700)" id="Vector_311" />
          <path d={svgPaths.p2eacd900} fill="var(--fill-0, #F5B700)" id="Vector_312" />
          <path d={svgPaths.p62cb000} fill="var(--fill-0, #F5B700)" id="Vector_313" />
          <path d={svgPaths.p5b43d00} fill="var(--fill-0, #F5B700)" id="Vector_314" />
          <path d={svgPaths.p25d82670} fill="var(--fill-0, #0F0F12)" id="Vector_315" />
          <path d={svgPaths.p940aa00} fill="var(--fill-0, #EAEAEA)" id="Vector_316" />
          <path d={svgPaths.pecf8a00} fill="var(--fill-0, #EAEAEA)" id="Vector_317" />
          <path d={svgPaths.p29d37200} fill="var(--fill-0, #EAEAEA)" id="Vector_318" />
          <path d={svgPaths.ped14400} fill="var(--fill-0, #F5B700)" id="Vector_319" />
          <path d={svgPaths.p411de00} fill="var(--fill-0, #0F0F12)" id="Vector_320" />
          <path d={svgPaths.pdf4fe00} fill="var(--fill-0, #0F0F12)" id="Vector_321" />
          <path d={svgPaths.p22c7d000} fill="var(--fill-0, #F5B700)" id="Vector_322" />
          <path d={svgPaths.p7d73400} fill="var(--fill-0, #9B8500)" id="Vector_323" />
          <path d={svgPaths.p76e2000} fill="var(--fill-0, #9B8500)" id="Vector_324" />
          <path d={svgPaths.p2f9baf00} fill="var(--fill-0, #9B8500)" id="Vector_325" />
          <path d={svgPaths.p39b95c80} fill="var(--fill-0, #0F0F12)" id="Vector_326" />
          <path d={svgPaths.p1f2ec780} fill="var(--fill-0, #EAEAEA)" id="Vector_327" />
          <path d={svgPaths.p1130cbc0} fill="var(--fill-0, #EAEAEA)" id="Vector_328" />
          <path d={svgPaths.p15b4b140} fill="var(--fill-0, #EAEAEA)" id="Vector_329" />
          <path d={svgPaths.p390dab00} fill="var(--fill-0, #F5B700)" id="Vector_330" />
          <path d={svgPaths.p3e52a600} fill="var(--fill-0, #F5B700)" id="Vector_331" />
          <path d={svgPaths.p18b9c180} fill="var(--fill-0, #F5B700)" id="Vector_332" />
          <path d={svgPaths.pb5f1400} fill="var(--fill-0, #F5B700)" id="Vector_333" />
          <path d={svgPaths.p105e3800} fill="var(--fill-0, #F5B700)" id="Vector_334" />
          <path d={svgPaths.p7ca2100} fill="var(--fill-0, #F5B700)" id="Vector_335" />
          <path d={svgPaths.p264f5800} fill="var(--fill-0, #F5B700)" id="Vector_336" />
          <path d={svgPaths.p68cb600} fill="var(--fill-0, #0F0F12)" id="Vector_337" />
          <path d={svgPaths.p11bd580} fill="var(--fill-0, #EAEAEA)" id="Vector_338" />
          <path d={svgPaths.p23748800} fill="var(--fill-0, #EAEAEA)" id="Vector_339" />
          <path d={svgPaths.p3670b300} fill="var(--fill-0, #EAEAEA)" id="Vector_340" />
          <path d={svgPaths.p28045c00} fill="var(--fill-0, #EAEAEA)" id="Vector_341" />
          <path d={svgPaths.pfba7430} fill="var(--fill-0, #EAEAEA)" id="Vector_342" />
          <path d={svgPaths.p2ee73700} fill="var(--fill-0, #F5B700)" id="Vector_343" />
          <path d={svgPaths.p3d76de00} fill="var(--fill-0, #F5B700)" id="Vector_344" />
          <path d={svgPaths.p3d320480} fill="var(--fill-0, #F5B700)" id="Vector_345" />
          <path d={svgPaths.p24772670} fill="var(--fill-0, #9B8500)" id="Vector_346" />
          <path d={svgPaths.p2574e100} fill="var(--fill-0, #9B8500)" id="Vector_347" />
          <path d={svgPaths.p1abc8f00} fill="var(--fill-0, #0F0F12)" id="Vector_348" />
          <path d={svgPaths.p81c7d00} fill="var(--fill-0, #0F0F12)" id="Vector_349" />
          <path d={svgPaths.p39044300} fill="var(--fill-0, #EAEAEA)" id="Vector_350" />
          <path d={svgPaths.pb652400} fill="var(--fill-0, #EAEAEA)" id="Vector_351" />
          <path d={svgPaths.pd9c0700} fill="var(--fill-0, #EAEAEA)" id="Vector_352" />
          <path d={svgPaths.p3b77c520} fill="var(--fill-0, #ED7793)" id="Vector_353" />
          <path d={svgPaths.pd8e680} fill="var(--fill-0, #EAEAEA)" id="Vector_354" />
          <path d={svgPaths.p8d22e00} fill="var(--fill-0, #EAEAEA)" id="Vector_355" />
          <path d={svgPaths.p3589e80} fill="var(--fill-0, #EAEAEA)" id="Vector_356" />
          <path d={svgPaths.p3227080} fill="var(--fill-0, #EAEAEA)" id="Vector_357" />
          <path d={svgPaths.p2f144780} fill="var(--fill-0, #F5B700)" id="Vector_358" />
          <path d={svgPaths.p1e6bf000} fill="var(--fill-0, #0F0F12)" id="Vector_359" />
          <path d={svgPaths.p307553c0} fill="var(--fill-0, #EAEAEA)" id="Vector_360" />
          <path d={svgPaths.p2b23700} fill="var(--fill-0, #0F0F12)" id="Vector_361" />
          <path d={svgPaths.p1153f200} fill="var(--fill-0, #EAEAEA)" id="Vector_362" />
          <path d={svgPaths.p22340b80} fill="var(--fill-0, #EAEAEA)" id="Vector_363" />
          <path d={svgPaths.p3c3edc70} fill="var(--fill-0, #ED7793)" id="Vector_364" />
          <path d={svgPaths.p23e3d100} fill="var(--fill-0, #EAEAEA)" id="Vector_365" />
          <path d={svgPaths.p3b47980} fill="var(--fill-0, #EAEAEA)" id="Vector_366" />
          <path d={svgPaths.p22d71700} fill="var(--fill-0, #EAEAEA)" id="Vector_367" />
          <path d={svgPaths.p3fb6b200} fill="var(--fill-0, #EAEAEA)" id="Vector_368" />
          <path d={svgPaths.p1baee770} fill="var(--fill-0, #F5B700)" id="Vector_369" />
          <path d={svgPaths.p2a15a100} fill="var(--fill-0, #0F0F12)" id="Vector_370" />
          <path d={svgPaths.p2f4f0300} fill="var(--fill-0, #EAEAEA)" id="Vector_371" />
          <path d={svgPaths.p36914300} fill="var(--fill-0, #EAEAEA)" id="Vector_372" />
          <path d={svgPaths.p2f63a3f0} fill="var(--fill-0, #0F0F12)" id="Vector_373" />
          <path d={svgPaths.p3b017f80} fill="var(--fill-0, #EAEAEA)" id="Vector_374" />
          <path d={svgPaths.p34413f80} fill="var(--fill-0, #EAEAEA)" id="Vector_375" />
          <path d={svgPaths.p2bb18800} fill="var(--fill-0, #F5B700)" id="Vector_376" />
          <path d={svgPaths.p205ed600} fill="var(--fill-0, #F5B700)" id="Vector_377" />
          <path d={svgPaths.p2fde8a00} fill="var(--fill-0, #F5B700)" id="Vector_378" />
          <path d={svgPaths.p25dfb400} fill="var(--fill-0, #9B8500)" id="Vector_379" />
          <path d={svgPaths.pd92380} fill="var(--fill-0, #9B8500)" id="Vector_380" />
          <path d={svgPaths.p1f3be280} fill="var(--fill-0, #0F0F12)" id="Vector_381" />
          <path d={svgPaths.p34310f00} fill="var(--fill-0, #EAEAEA)" id="Vector_382" />
          <path d={svgPaths.p28995880} fill="var(--fill-0, #EAEAEA)" id="Vector_383" />
          <path d={svgPaths.p35f3300} fill="var(--fill-0, #0F0F12)" id="Vector_384" />
          <path d={svgPaths.pc4a5480} fill="var(--fill-0, #F5B700)" id="Vector_385" />
          <path d={svgPaths.p225d6780} fill="var(--fill-0, #F5B700)" id="Vector_386" />
          <path d={svgPaths.p694c2c0} fill="var(--fill-0, #F5B700)" id="Vector_387" />
          <path d={svgPaths.p222a0a00} fill="var(--fill-0, #F5B700)" id="Vector_388" />
          <path d={svgPaths.p3f164e00} fill="var(--fill-0, #F5B700)" id="Vector_389" />
          <path d={svgPaths.p27f4d680} fill="var(--fill-0, #F5B700)" id="Vector_390" />
          <path d={svgPaths.p8a80f90} fill="var(--fill-0, #F5B700)" id="Vector_391" />
          <path d={svgPaths.p1efb59f0} fill="var(--fill-0, #0F0F12)" id="Vector_392" />
          <path d={svgPaths.p25492600} fill="var(--fill-0, #EAEAEA)" id="Vector_393" />
          <path d={svgPaths.p1a8c3000} fill="var(--fill-0, #EAEAEA)" id="Vector_394" />
          <path d={svgPaths.p2ef7a900} fill="var(--fill-0, #0F0F12)" id="Vector_395" />
          <path d={svgPaths.p3629c5f0} fill="var(--fill-0, #F5B700)" id="Vector_396" />
          <path d={svgPaths.p1adfd800} fill="var(--fill-0, #0F0F12)" id="Vector_397" />
          <path d={svgPaths.p489c360} fill="var(--fill-0, #0F0F12)" id="Vector_398" />
          <path d={svgPaths.p2fae8ff2} fill="var(--fill-0, #F5B700)" id="Vector_399" />
          <path d={svgPaths.p23e03300} fill="var(--fill-0, #9B8500)" id="Vector_400" />
          <path d={svgPaths.p2a0c2480} fill="var(--fill-0, #9B8500)" id="Vector_401" />
          <path d={svgPaths.p25ad0600} fill="var(--fill-0, #9B8500)" id="Vector_402" />
          <path d={svgPaths.p6a62c00} fill="var(--fill-0, #0F0F12)" id="Vector_403" />
          <path d={svgPaths.pcdabb00} fill="var(--fill-0, #EAEAEA)" id="Vector_404" />
          <path d={svgPaths.p193355c0} fill="var(--fill-0, #EAEAEA)" id="Vector_405" />
          <path d={svgPaths.p19e9bd00} fill="var(--fill-0, #0F0F12)" id="Vector_406" />
          <path d={svgPaths.p8a1b800} fill="var(--fill-0, #F5B700)" id="Vector_407" />
          <path d={svgPaths.p28fcab00} fill="var(--fill-0, #0F0F12)" id="Vector_408" />
          <path d={svgPaths.p135225f0} fill="var(--fill-0, #0F0F12)" id="Vector_409" />
          <path d={svgPaths.p1b632080} fill="var(--fill-0, #F5B700)" id="Vector_410" />
          <path d={svgPaths.pf8d7f00} fill="var(--fill-0, #F5B700)" id="Vector_411" />
          <path d={svgPaths.p11142500} fill="var(--fill-0, #F5B700)" id="Vector_412" />
          <path d={svgPaths.p8fb7300} fill="var(--fill-0, #F5B700)" id="Vector_413" />
          <path d={svgPaths.p14757780} fill="var(--fill-0, #0F0F12)" id="Vector_414" />
          <path d={svgPaths.p2050f600} fill="var(--fill-0, #EAEAEA)" id="Vector_415" />
          <path d={svgPaths.p1e183800} fill="var(--fill-0, #EAEAEA)" id="Vector_416" />
          <path d={svgPaths.p304ad2f0} fill="var(--fill-0, #F5B700)" id="Vector_417" />
          <path d={svgPaths.p1204b680} fill="var(--fill-0, #F5B700)" id="Vector_418" />
          <path d={svgPaths.p20d6d520} fill="var(--fill-0, #F5B700)" id="Vector_419" />
          <path d={svgPaths.p1e76f80} fill="var(--fill-0, #F5B700)" id="Vector_420" />
          <path d={svgPaths.p1d59cfb0} fill="var(--fill-0, #F5B700)" id="Vector_421" />
          <path d={svgPaths.p208a1300} fill="var(--fill-0, #F5B700)" id="Vector_422" />
          <path d={svgPaths.pb081a00} fill="var(--fill-0, #F5B700)" id="Vector_423" />
          <path d={svgPaths.p98270f0} fill="var(--fill-0, #0F0F12)" id="Vector_424" />
          <path d={svgPaths.p2ef20480} fill="var(--fill-0, #0F0F12)" id="Vector_425" />
          <path d={svgPaths.p3b337540} fill="var(--fill-0, #F5B700)" id="Vector_426" />
          <path d={svgPaths.p296acc80} fill="var(--fill-0, #F5B700)" id="Vector_427" />
          <path d={svgPaths.p3a196d00} fill="var(--fill-0, #9B8500)" id="Vector_428" />
          <path d={svgPaths.p15f5ba70} fill="var(--fill-0, #F5B700)" id="Vector_429" />
          <path d={svgPaths.p1367e500} fill="var(--fill-0, #9B8500)" id="Vector_430" />
          <path d={svgPaths.p11138080} fill="var(--fill-0, #F5B700)" id="Vector_431" />
          <path d={svgPaths.p3ca22180} fill="var(--fill-0, #F5B700)" id="Vector_432" />
          <path d={svgPaths.p13aae500} fill="var(--fill-0, #F5B700)" id="Vector_433" />
          <path d={svgPaths.p3371620} fill="var(--fill-0, #0F0F12)" id="Vector_434" />
          <path d={svgPaths.pa04a9f0} fill="var(--fill-0, #EAEAEA)" id="Vector_435" />
          <path d={svgPaths.pc30eb0} fill="var(--fill-0, #EAEAEA)" id="Vector_436" />
          <path d={svgPaths.p296c4380} fill="var(--fill-0, #0F0F12)" id="Vector_437" />
          <path d={svgPaths.p21b21300} fill="var(--fill-0, #F5B700)" id="Vector_438" />
          <path d={svgPaths.p95e6a00} fill="var(--fill-0, #9B8500)" id="Vector_439" />
          <path d={svgPaths.p2683d4a0} fill="var(--fill-0, #F5B700)" id="Vector_440" />
          <path d={svgPaths.p1984f300} fill="var(--fill-0, #9B8500)" id="Vector_441" />
          <path d={svgPaths.p24c589f0} fill="var(--fill-0, #0F0F12)" id="Vector_442" />
          <path d={svgPaths.p3bfab400} fill="var(--fill-0, #0F0F12)" id="Vector_443" />
          <path d={svgPaths.p2c36a500} fill="var(--fill-0, #0F0F12)" id="Vector_444" />
          <path d={svgPaths.p2ba1eb00} fill="var(--fill-0, #EAEAEA)" id="Vector_445" />
          <path d={svgPaths.p337a2480} fill="var(--fill-0, #EAEAEA)" id="Vector_446" />
          <path d={svgPaths.pe728920} fill="var(--fill-0, #EAEAEA)" id="Vector_447" />
          <path d={svgPaths.p1235200} fill="var(--fill-0, #EAEAEA)" id="Vector_448" />
          <path d={svgPaths.p2de4a800} fill="var(--fill-0, #0F0F12)" id="Vector_449" />
          <path d={svgPaths.p99d6280} fill="var(--fill-0, #0F0F12)" id="Vector_450" />
          <path d={svgPaths.p2ee4c800} fill="var(--fill-0, #0F0F12)" id="Vector_451" />
          <path d={svgPaths.p2ac6a700} fill="var(--fill-0, #0F0F12)" id="Vector_452" />
          <path d={svgPaths.p31731680} fill="var(--fill-0, #0F0F12)" id="Vector_453" />
          <path d={svgPaths.p1b0da180} fill="var(--fill-0, #0F0F12)" id="Vector_454" />
          <path d={svgPaths.p22994700} fill="var(--fill-0, #0F0F12)" id="Vector_455" />
        </g>
      </svg>
    </div>
  );
}

function PixelArtCat() {
  return (
    <div className="absolute left-[1129px] overflow-clip size-[83px] top-[2032px]" data-name="PixelArtCat-02 1">
      <Group />
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[1440px]">
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute content-stretch flex items-center left-0 top-0 w-[1456px]">
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[1440px]">
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
    </div>
  );
}

function Frame4() {
  return (
    <div className="absolute content-stretch flex items-center left-0 top-0 w-[1456px]">
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[1440px]">
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
      <div className="bg-[rgba(217,217,217,0)] h-[56px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
      </div>
    </div>
  );
}

function Frame6() {
  return (
    <div className="absolute content-stretch flex items-center left-0 top-0 w-[1456px]">
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
      <div className="flex h-[1176px] items-center justify-center relative shrink-0 w-[56px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[rgba(217,217,217,0)] h-[56px] relative w-[1176px]">
            <div aria-hidden="true" className="absolute border border-[#17171c] border-solid inset-[-0.5px] pointer-events-none" />
          </div>
        </div>
      </div>
    </div>
  );
}

function BgSurface() {
  return (
    <div className="-translate-x-1/2 absolute contents left-[calc(50%+8px)] top-0" data-name="bg-surface">
      <div className="-translate-x-1/2 absolute content-stretch flex flex-col gap-[10px] h-[1168.364px] items-start left-[calc(50%+8px)] opacity-3 top-[1168.36px] w-[1456px]" data-name="bg-mesh">
        <Frame2 />
        <Frame1 />
      </div>
      <div className="-translate-x-1/2 absolute content-stretch flex flex-col gap-[10px] h-[1168.364px] items-start left-[calc(50%+8px)] opacity-3 top-[1279.64px] w-[1456px]" data-name="bg-mesh">
        <Frame3 />
        <Frame4 />
      </div>
      <div className="-translate-x-1/2 absolute content-stretch flex flex-col gap-[10px] h-[1168.364px] items-start left-[calc(50%+8px)] opacity-3 top-0 w-[1456px]" data-name="bg-mesh">
        <Frame5 />
        <Frame6 />
      </div>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-0 top-0">
      <div className="absolute h-[96px] left-0 pointer-events-none top-0 w-[1440px]" data-name="Overlay">
        <div aria-hidden="true" className="absolute inset-0">
          <div className="absolute bg-[rgba(68,68,68,0.6)] inset-0 mix-blend-lighten" />
          <div className="absolute bg-[#eee] inset-0" />
          <div className="absolute backdrop-blur-[8px] bg-[#111] inset-0 mix-blend-plus-lighter" />
        </div>
        <div aria-hidden="true" className="absolute border-0 border-black border-solid inset-0" />
      </div>
    </div>
  );
}

function BgNavbar() {
  return (
    <div className="absolute contents left-[-1px] top-0" data-name="bg-navbar">
      <Group1 />
      <div className="absolute bg-white h-[96px] left-[-1px] opacity-70 top-0 w-[1440px]" />
    </div>
  );
}

function Frame() {
  return (
    <div className="absolute h-[23.912px] left-[3.69px] top-[8px] w-[31.923px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 31.9231 23.9117">
        <g id="Frame 6">
          <path d={svgPaths.p3cd78c00} fill="var(--fill-0, #EAEAEA)" id="{" />
          <path d={svgPaths.p1fe17672} fill="var(--fill-0, #EAEAEA)" id="B" />
        </g>
      </svg>
    </div>
  );
}

function Frame25() {
  return (
    <div className="absolute content-stretch flex gap-[24px] items-center left-[936px] top-[32px]">
      <div className="relative shrink-0 size-[32px]" data-name="image 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage1} />
      </div>
      <div className="relative shrink-0 size-[32px]" data-name="LI-In-Bug 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-full left-0 max-w-none top-0 w-[117.59%]" src={imgLiInBug1} />
        </div>
      </div>
    </div>
  );
}

function Frame8() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[96px] left-1/2 overflow-clip top-1/2 w-[1024px]">
      <div className="-translate-y-1/2 absolute content-stretch flex gap-[3.692px] items-center left-0 top-1/2 w-[208px]" data-name="mark-logo">
        <div className="bg-[#17171c] overflow-clip relative rounded-[12px] shrink-0 size-[48px]" data-name="ic-logo">
          <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 overflow-clip size-[39.385px] top-1/2" data-name="mark">
            <Frame />
          </div>
        </div>
        <div className="h-[23.914px] relative shrink-0 w-[157.148px]" data-name="racket">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 157.148 23.9138">
            <g id="racket">
              <path d={svgPaths.p27ca7490} fill="#17171C" />
              <path d={svgPaths.p7614780} fill="#17171C" />
              <path d={svgPaths.p30bc51c0} fill="#17171C" />
              <path d={svgPaths.pe7c6900} fill="#17171C" />
              <path d={svgPaths.pbf322c0} fill="#17171C" />
              <path d={svgPaths.pe9e7600} fill="#17171C" />
            </g>
          </svg>
        </div>
      </div>
      <Frame25 />
    </div>
  );
}

function Navbar() {
  return (
    <div className="-translate-x-1/2 absolute h-[96px] left-1/2 top-0 w-[1440px]" data-name="navbar">
      <BgNavbar />
      <Frame8 />
    </div>
  );
}

function Cat() {
  return (
    <div className="absolute inset-[11.74%_44.24%_87.03%_53.26%]" data-name="cat-01">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36.0002 30">
        <g id="cat-01">
          <path d={svgPaths.p17926980} fill="var(--fill-0, #0F0F12)" id="Vector" />
          <path d={svgPaths.p1730e2f0} fill="var(--fill-0, #0F0F12)" id="Vector_2" />
          <path d={svgPaths.p12211300} fill="var(--fill-0, #0F0F12)" id="Vector_3" />
          <path d={svgPaths.p385be600} fill="var(--fill-0, #0F0F12)" id="Vector_4" />
          <path d={svgPaths.p23456400} fill="var(--fill-0, #0F0F12)" id="Vector_5" />
          <path d={svgPaths.p2a1914f0} fill="var(--fill-0, #0F0F12)" id="Vector_6" />
          <path d={svgPaths.p32a7b100} fill="var(--fill-0, #0F0F12)" id="Vector_7" />
          <path d={svgPaths.p3e131700} fill="var(--fill-0, #0F0F12)" id="Vector_8" />
          <path d={svgPaths.p2d77a900} fill="var(--fill-0, #0F0F12)" id="Vector_9" />
          <path d={svgPaths.paf3ac00} fill="var(--fill-0, #0F0F12)" id="Vector_10" />
          <path d={svgPaths.p10a0d900} fill="var(--fill-0, #9B8500)" id="Vector_11" />
          <path d={svgPaths.p30c6f200} fill="var(--fill-0, #F5B700)" id="Vector_12" />
          <path d={svgPaths.p2621db00} fill="var(--fill-0, #9B8500)" id="Vector_13" />
          <path d={svgPaths.p2fc83d00} fill="var(--fill-0, #0F0F12)" id="Vector_14" />
          <path d={svgPaths.p247d3ee0} fill="var(--fill-0, #0F0F12)" id="Vector_15" />
          <path d={svgPaths.p19ee0e80} fill="var(--fill-0, #0F0F12)" id="Vector_16" />
          <path d={svgPaths.p3a37b900} fill="var(--fill-0, #EAEAEA)" id="Vector_17" />
          <path d={svgPaths.pf6d9900} fill="var(--fill-0, #EAEAEA)" id="Vector_18" />
          <path d={svgPaths.p3d6f3970} fill="var(--fill-0, #EAEAEA)" id="Vector_19" />
          <path d={svgPaths.p284c2680} fill="var(--fill-0, #EAEAEA)" id="Vector_20" />
          <path d={svgPaths.p1802ab00} fill="var(--fill-0, #0F0F12)" id="Vector_21" />
          <path d={svgPaths.p236edcf0} fill="var(--fill-0, #0F0F12)" id="Vector_22" />
          <path d={svgPaths.pd7f9980} fill="var(--fill-0, #F5B700)" id="Vector_23" />
          <path d={svgPaths.p2861a980} fill="var(--fill-0, #9B8500)" id="Vector_24" />
          <path d={svgPaths.p7e07080} fill="var(--fill-0, #F5B700)" id="Vector_25" />
          <path d={svgPaths.p399b2a00} fill="var(--fill-0, #9B8500)" id="Vector_26" />
          <path d={svgPaths.p1218f00} fill="var(--fill-0, #F5B700)" id="Vector_27" />
          <path d={svgPaths.p3f077800} fill="var(--fill-0, #F5B700)" id="Vector_28" />
          <path d={svgPaths.p2f072100} fill="var(--fill-0, #F5B700)" id="Vector_29" />
          <path d={svgPaths.p16c7ea80} fill="var(--fill-0, #0F0F12)" id="Vector_30" />
          <path d={svgPaths.p12d4eb40} fill="var(--fill-0, #EAEAEA)" id="Vector_31" />
          <path d={svgPaths.p2b579900} fill="var(--fill-0, #EAEAEA)" id="Vector_32" />
          <path d={svgPaths.p3c069c00} fill="var(--fill-0, #0F0F12)" id="Vector_33" />
          <path d={svgPaths.p2a62b400} fill="var(--fill-0, #0F0F12)" id="Vector_34" />
          <path d="M28.8 25H27V26.6667H28.8V25Z" fill="var(--fill-0, #0F0F12)" id="Vector_35" />
          <path d={svgPaths.p1ee07100} fill="var(--fill-0, #EAEAEA)" id="Vector_36" />
          <path d={svgPaths.p3a529c80} fill="var(--fill-0, #EAEAEA)" id="Vector_37" />
          <path d={svgPaths.p11666880} fill="var(--fill-0, #F5B700)" id="Vector_38" />
          <path d="M28.8 15H27V16.6666H28.8V15Z" fill="var(--fill-0, #F5B700)" id="Vector_39" />
          <path d={svgPaths.p22cc7680} fill="var(--fill-0, #F5B700)" id="Vector_40" />
          <path d={svgPaths.p2e396800} fill="var(--fill-0, #F5B700)" id="Vector_41" />
          <path d="M28.8 10H27V11.6667H28.8V10Z" fill="var(--fill-0, #F5B700)" id="Vector_42" />
          <path d={svgPaths.p390d5780} fill="var(--fill-0, #F5B700)" id="Vector_43" />
          <path d={svgPaths.p2ad8900} fill="var(--fill-0, #F5B700)" id="Vector_44" />
          <path d={svgPaths.p6c5a670} fill="var(--fill-0, #0F0F12)" id="Vector_45" />
          <path d={svgPaths.p27a3e700} fill="var(--fill-0, #0F0F12)" id="Vector_46" />
          <path d={svgPaths.p3fa7db00} fill="var(--fill-0, #0F0F12)" id="Vector_47" />
          <path d={svgPaths.p37398200} fill="var(--fill-0, #0F0F12)" id="Vector_48" />
          <path d={svgPaths.p2d9f6c80} fill="var(--fill-0, #EAEAEA)" id="Vector_49" />
          <path d={svgPaths.p31144b80} fill="var(--fill-0, #EAEAEA)" id="Vector_50" />
          <path d={svgPaths.p3d119a00} fill="var(--fill-0, #EAEAEA)" id="Vector_51" />
          <path d={svgPaths.p293a0500} fill="var(--fill-0, #F5B700)" id="Vector_52" />
          <path d={svgPaths.p114be0f0} fill="var(--fill-0, #0F0F12)" id="Vector_53" />
          <path d={svgPaths.p31842070} fill="var(--fill-0, #EAEAEA)" id="Vector_54" />
          <path d={svgPaths.p2c6b8d00} fill="var(--fill-0, #F5B700)" id="Vector_55" />
          <path d={svgPaths.p3c112900} fill="var(--fill-0, #F5B700)" id="Vector_56" />
          <path d={svgPaths.p226e1bf0} fill="var(--fill-0, #F5B700)" id="Vector_57" />
          <path d={svgPaths.p39850900} fill="var(--fill-0, #F5B700)" id="Vector_58" />
          <path d={svgPaths.p15381480} fill="var(--fill-0, #0F0F12)" id="Vector_59" />
          <path d={svgPaths.p1bdcfe72} fill="var(--fill-0, #F5B700)" id="Vector_60" />
          <path d={svgPaths.pc29a080} fill="var(--fill-0, #F5B700)" id="Vector_61" />
          <path d={svgPaths.p2469700} fill="var(--fill-0, #F5B700)" id="Vector_62" />
          <path d={svgPaths.pd061200} fill="var(--fill-0, #0F0F12)" id="Vector_63" />
          <path d={svgPaths.p343c4570} fill="var(--fill-0, #EAEAEA)" id="Vector_64" />
          <path d={svgPaths.p3ee1ef80} fill="var(--fill-0, #EAEAEA)" id="Vector_65" />
          <path d={svgPaths.pa8c5300} fill="var(--fill-0, #EAEAEA)" id="Vector_66" />
          <path d={svgPaths.p8ea000} fill="var(--fill-0, #F5B700)" id="Vector_67" />
          <path d={svgPaths.p37b0f200} fill="var(--fill-0, #0F0F12)" id="Vector_68" />
          <path d={svgPaths.p1b2cbe80} fill="var(--fill-0, #0F0F12)" id="Vector_69" />
          <path d={svgPaths.p60f0e00} fill="var(--fill-0, #F5B700)" id="Vector_70" />
          <path d={svgPaths.p26992280} fill="var(--fill-0, #9B8500)" id="Vector_71" />
          <path d={svgPaths.p1ccab9f0} fill="var(--fill-0, #9B8500)" id="Vector_72" />
          <path d={svgPaths.p235bc200} fill="var(--fill-0, #9B8500)" id="Vector_73" />
          <path d={svgPaths.pf4fd200} fill="var(--fill-0, #0F0F12)" id="Vector_74" />
          <path d={svgPaths.pc68f280} fill="var(--fill-0, #F5B700)" id="Vector_75" />
          <path d={svgPaths.p21b42700} fill="var(--fill-0, #F5B700)" id="Vector_76" />
          <path d={svgPaths.p24643a00} fill="var(--fill-0, #F5B700)" id="Vector_77" />
          <path d={svgPaths.p337b100} fill="var(--fill-0, #EAEAEA)" id="Vector_78" />
          <path d={svgPaths.p10a90400} fill="var(--fill-0, #EAEAEA)" id="Vector_79" />
          <path d={svgPaths.p384f71} fill="var(--fill-0, #EAEAEA)" id="Vector_80" />
          <path d={svgPaths.p1bc0ac80} fill="var(--fill-0, #F5B700)" id="Vector_81" />
          <path d={svgPaths.p2691f900} fill="var(--fill-0, #F5B700)" id="Vector_82" />
          <path d={svgPaths.p35163200} fill="var(--fill-0, #F5B700)" id="Vector_83" />
          <path d={svgPaths.p2e01e180} fill="var(--fill-0, #F5B700)" id="Vector_84" />
          <path d={svgPaths.p38060d00} fill="var(--fill-0, #F5B700)" id="Vector_85" />
          <path d={svgPaths.ped78800} fill="var(--fill-0, #F5B700)" id="Vector_86" />
          <path d={svgPaths.p1fd27500} fill="var(--fill-0, #F5B700)" id="Vector_87" />
          <path d={svgPaths.p3254a980} fill="var(--fill-0, #0F0F12)" id="Vector_88" />
          <path d={svgPaths.pc8d15f0} fill="var(--fill-0, #EAEAEA)" id="Vector_89" />
          <path d={svgPaths.p1d987ef0} fill="var(--fill-0, #EAEAEA)" id="Vector_90" />
          <path d={svgPaths.p1c56a100} fill="var(--fill-0, #EAEAEA)" id="Vector_91" />
          <path d={svgPaths.p3db29400} fill="var(--fill-0, #EAEAEA)" id="Vector_92" />
          <path d={svgPaths.p32876900} fill="var(--fill-0, #EAEAEA)" id="Vector_93" />
          <path d={svgPaths.p194e2300} fill="var(--fill-0, #EAEAEA)" id="Vector_94" />
          <path d={svgPaths.p3f089100} fill="var(--fill-0, #EAEAEA)" id="Vector_95" />
          <path d={svgPaths.p2e775500} fill="var(--fill-0, #EAEAEA)" id="Vector_96" />
          <path d={svgPaths.p17227c00} fill="var(--fill-0, #F5B700)" id="Vector_97" />
          <path d={svgPaths.p3798c480} fill="var(--fill-0, #F5B700)" id="Vector_98" />
          <path d={svgPaths.pbda600} fill="var(--fill-0, #F5B700)" id="Vector_99" />
          <path d={svgPaths.p27dbe600} fill="var(--fill-0, #9B8500)" id="Vector_100" />
          <path d={svgPaths.p8dc4100} fill="var(--fill-0, #9B8500)" id="Vector_101" />
          <path d={svgPaths.p34f11c00} fill="var(--fill-0, #0F0F12)" id="Vector_102" />
          <path d="M19.8 25H18V26.6667H19.8V25Z" fill="var(--fill-0, #EAEAEA)" id="Vector_103" />
          <path d={svgPaths.p29751100} fill="var(--fill-0, #EAEAEA)" id="Vector_104" />
          <path d={svgPaths.p38b0b780} fill="var(--fill-0, #EAEAEA)" id="Vector_105" />
          <path d={svgPaths.pd9017ea} fill="var(--fill-0, #EAEAEA)" id="Vector_106" />
          <path d={svgPaths.p3dc63180} fill="var(--fill-0, #EAEAEA)" id="Vector_107" />
          <path d={svgPaths.p3a3a100} fill="var(--fill-0, #EAEAEA)" id="Vector_108" />
          <path d="M19.8 15H18V16.6666H19.8V15Z" fill="var(--fill-0, #EAEAEA)" id="Vector_109" />
          <path d={svgPaths.p35095a80} fill="var(--fill-0, #ED7793)" id="Vector_110" />
          <path d={svgPaths.p144c700} fill="var(--fill-0, #F5B700)" id="Vector_111" />
          <path d="M19.8 10H18V11.6667H19.8V10Z" fill="var(--fill-0, #F5B700)" id="Vector_112" />
          <path d={svgPaths.p3aa98600} fill="var(--fill-0, #F5B700)" id="Vector_113" />
          <path d={svgPaths.pbd73200} fill="var(--fill-0, #F5B700)" id="Vector_114" />
          <path d={svgPaths.p18df100} fill="var(--fill-0, #F5B700)" id="Vector_115" />
          <path d={svgPaths.p12360700} fill="var(--fill-0, #0F0F12)" id="Vector_116" />
          <path d={svgPaths.p1ddf6b00} fill="var(--fill-0, #EAEAEA)" id="Vector_117" />
          <path d={svgPaths.pd6f0700} fill="var(--fill-0, #EAEAEA)" id="Vector_118" />
          <path d={svgPaths.p1e3a1580} fill="var(--fill-0, #EAEAEA)" id="Vector_119" />
          <path d={svgPaths.p31edd600} fill="var(--fill-0, #EAEAEA)" id="Vector_120" />
          <path d={svgPaths.p7409300} fill="var(--fill-0, #EAEAEA)" id="Vector_121" />
          <path d={svgPaths.p2831c4f0} fill="var(--fill-0, #EAEAEA)" id="Vector_122" />
          <path d={svgPaths.p18154c70} fill="var(--fill-0, #EAEAEA)" id="Vector_123" />
          <path d={svgPaths.p13cf0180} fill="var(--fill-0, #ED7793)" id="Vector_124" />
          <path d={svgPaths.p7bbca00} fill="var(--fill-0, #F5B700)" id="Vector_125" />
          <path d={svgPaths.p36c3b5f0} fill="var(--fill-0, #F5B700)" id="Vector_126" />
          <path d={svgPaths.p25a14b00} fill="var(--fill-0, #F5B700)" id="Vector_127" />
          <path d={svgPaths.p1d3b2f00} fill="var(--fill-0, #F5B700)" id="Vector_128" />
          <path d={svgPaths.p267ed000} fill="var(--fill-0, #F5B700)" id="Vector_129" />
          <path d={svgPaths.p142e2500} fill="var(--fill-0, #0F0F12)" id="Vector_130" />
          <path d={svgPaths.pe619400} fill="var(--fill-0, #EAEAEA)" id="Vector_131" />
          <path d={svgPaths.p3cf7eb00} fill="var(--fill-0, #EAEAEA)" id="Vector_132" />
          <path d={svgPaths.p89d9780} fill="var(--fill-0, #EAEAEA)" id="Vector_133" />
          <path d={svgPaths.p6033840} fill="var(--fill-0, #EAEAEA)" id="Vector_134" />
          <path d={svgPaths.pb368d20} fill="var(--fill-0, #EAEAEA)" id="Vector_135" />
          <path d={svgPaths.p33045700} fill="var(--fill-0, #EAEAEA)" id="Vector_136" />
          <path d={svgPaths.p3a498c80} fill="var(--fill-0, #EAEAEA)" id="Vector_137" />
          <path d={svgPaths.p30872400} fill="var(--fill-0, #EAEAEA)" id="Vector_138" />
          <path d={svgPaths.pc6b5080} fill="var(--fill-0, #F5B700)" id="Vector_139" />
          <path d={svgPaths.p18467400} fill="var(--fill-0, #F5B700)" id="Vector_140" />
          <path d={svgPaths.p261f2700} fill="var(--fill-0, #F5B700)" id="Vector_141" />
          <path d={svgPaths.p27266480} fill="var(--fill-0, #9B8500)" id="Vector_142" />
          <path d={svgPaths.p1be75d00} fill="var(--fill-0, #9B8500)" id="Vector_143" />
          <path d={svgPaths.p1af61280} fill="var(--fill-0, #0F0F12)" id="Vector_144" />
          <path d={svgPaths.p20968480} fill="var(--fill-0, #F5B700)" id="Vector_145" />
          <path d={svgPaths.p19745c00} fill="var(--fill-0, #F5B700)" id="Vector_146" />
          <path d={svgPaths.p3deaee00} fill="var(--fill-0, #F5B700)" id="Vector_147" />
          <path d={svgPaths.p3a8ac800} fill="var(--fill-0, #EAEAEA)" id="Vector_148" />
          <path d={svgPaths.pdf9e370} fill="var(--fill-0, #EAEAEA)" id="Vector_149" />
          <path d={svgPaths.p3df92380} fill="var(--fill-0, #EAEAEA)" id="Vector_150" />
          <path d={svgPaths.p161d6c00} fill="var(--fill-0, #F5B700)" id="Vector_151" />
          <path d={svgPaths.p206c0980} fill="var(--fill-0, #F5B700)" id="Vector_152" />
          <path d={svgPaths.p3bb52600} fill="var(--fill-0, #F5B700)" id="Vector_153" />
          <path d={svgPaths.p29965640} fill="var(--fill-0, #F5B700)" id="Vector_154" />
          <path d={svgPaths.p3fc72b00} fill="var(--fill-0, #F5B700)" id="Vector_155" />
          <path d={svgPaths.p13d52600} fill="var(--fill-0, #F5B700)" id="Vector_156" />
          <path d={svgPaths.p13433b40} fill="var(--fill-0, #F5B700)" id="Vector_157" />
          <path d={svgPaths.p14c19300} fill="var(--fill-0, #0F0F12)" id="Vector_158" />
          <path d={svgPaths.p309c1d80} fill="var(--fill-0, #F5B700)" id="Vector_159" />
          <path d={svgPaths.p23c8b780} fill="var(--fill-0, #F5B700)" id="Vector_160" />
          <path d={svgPaths.p38d38300} fill="var(--fill-0, #0F0F12)" id="Vector_161" />
          <path d={svgPaths.p33e76880} fill="var(--fill-0, #EAEAEA)" id="Vector_162" />
          <path d={svgPaths.p5baec00} fill="var(--fill-0, #EAEAEA)" id="Vector_163" />
          <path d={svgPaths.p79f7800} fill="var(--fill-0, #EAEAEA)" id="Vector_164" />
          <path d={svgPaths.p59af200} fill="var(--fill-0, #F5B700)" id="Vector_165" />
          <path d={svgPaths.p8264980} fill="var(--fill-0, #0F0F12)" id="Vector_166" />
          <path d={svgPaths.p32685300} fill="var(--fill-0, #EAEAEA)" id="Vector_167" />
          <path d={svgPaths.p38c36e00} fill="var(--fill-0, #F5B700)" id="Vector_168" />
          <path d={svgPaths.p1ad0f880} fill="var(--fill-0, #9B8500)" id="Vector_169" />
          <path d={svgPaths.p13e05600} fill="var(--fill-0, #9B8500)" id="Vector_170" />
          <path d={svgPaths.p2c704d80} fill="var(--fill-0, #9B8500)" id="Vector_171" />
          <path d={svgPaths.p17fd7400} fill="var(--fill-0, #0F0F12)" id="Vector_172" />
          <path d={svgPaths.p2830c300} fill="var(--fill-0, #F5B700)" id="Vector_173" />
          <path d={svgPaths.p8babaf0} fill="var(--fill-0, #0F0F12)" id="Vector_174" />
          <path d={svgPaths.p18649800} fill="var(--fill-0, #0F0F12)" id="Vector_175" />
          <path d={svgPaths.p16bc0e80} fill="var(--fill-0, #EAEAEA)" id="Vector_176" />
          <path d={svgPaths.p37bf1880} fill="var(--fill-0, #EAEAEA)" id="Vector_177" />
          <path d={svgPaths.p7c14c40} fill="var(--fill-0, #EAEAEA)" id="Vector_178" />
          <path d={svgPaths.p1f625f00} fill="var(--fill-0, #F5B700)" id="Vector_179" />
          <path d={svgPaths.pcb80000} fill="var(--fill-0, #0F0F12)" id="Vector_180" />
          <path d={svgPaths.p37a89900} fill="var(--fill-0, #0F0F12)" id="Vector_181" />
          <path d={svgPaths.p33925d00} fill="var(--fill-0, #F5B700)" id="Vector_182" />
          <path d={svgPaths.p197d8a00} fill="var(--fill-0, #F5B700)" id="Vector_183" />
          <path d={svgPaths.pf84e000} fill="var(--fill-0, #F5B700)" id="Vector_184" />
          <path d={svgPaths.p27858f00} fill="var(--fill-0, #F5B700)" id="Vector_185" />
          <path d={svgPaths.p34f9b600} fill="var(--fill-0, #0F0F12)" id="Vector_186" />
          <path d={svgPaths.p2c34a6f0} fill="var(--fill-0, #0F0F12)" id="Vector_187" />
          <path d={svgPaths.p3c32ff80} fill="var(--fill-0, #0F0F12)" id="Vector_188" />
          <path d={svgPaths.p12a33d40} fill="var(--fill-0, #0F0F12)" id="Vector_189" />
          <path d={svgPaths.p2ef97f00} fill="var(--fill-0, #0F0F12)" id="Vector_190" />
          <path d={svgPaths.p37209d00} fill="var(--fill-0, #0F0F12)" id="Vector_191" />
          <path d={svgPaths.p3689c580} fill="var(--fill-0, #EAEAEA)" id="Vector_192" />
          <path d={svgPaths.p2bfaec00} fill="var(--fill-0, #EAEAEA)" id="Vector_193" />
          <path d={svgPaths.p23190e00} fill="var(--fill-0, #EAEAEA)" id="Vector_194" />
          <path d={svgPaths.p995b700} fill="var(--fill-0, #EAEAEA)" id="Vector_195" />
          <path d={svgPaths.p6c26780} fill="var(--fill-0, #0F0F12)" id="Vector_196" />
          <path d={svgPaths.p2328680} fill="var(--fill-0, #0F0F12)" id="Vector_197" />
          <path d={svgPaths.p1af0a00} fill="var(--fill-0, #0F0F12)" id="Vector_198" />
          <path d={svgPaths.p21283300} fill="var(--fill-0, #0F0F12)" id="Vector_199" />
          <path d={svgPaths.p3d383b80} fill="var(--fill-0, #F6BB0F)" id="Vector_200" />
          <path d={svgPaths.p1de55980} fill="var(--fill-0, #F6BB0F)" id="Vector_201" />
          <path d={svgPaths.p5b2b000} fill="var(--fill-0, #F6BB0F)" id="Vector_202" />
          <path d={svgPaths.p1f318100} fill="var(--fill-0, #F6BB0F)" id="Vector_203" />
          <path d={svgPaths.pa396880} fill="var(--fill-0, #F6BB0F)" id="Vector_204" />
          <path d={svgPaths.p2de0eb00} fill="var(--fill-0, #F6BB0F)" id="Vector_205" />
          <path d={svgPaths.pe43700} fill="var(--fill-0, #F6BB0F)" id="Vector_206" />
          <path d={svgPaths.p192a0480} fill="var(--fill-0, #F6BB0F)" id="Vector_207" />
          <path d={svgPaths.p34493a00} fill="var(--fill-0, #0F0F12)" id="Vector_208" />
          <path d={svgPaths.p26ca8980} fill="var(--fill-0, #EAEAEA)" id="Vector_209" />
          <path d={svgPaths.p12bee580} fill="var(--fill-0, #EAEAEA)" id="Vector_210" />
          <path d={svgPaths.p2d24e980} fill="var(--fill-0, #F5B700)" id="Vector_211" />
          <path d={svgPaths.p6cd0880} fill="var(--fill-0, #F5B700)" id="Vector_212" />
          <path d={svgPaths.p27259480} fill="var(--fill-0, #F5B700)" id="Vector_213" />
          <path d={svgPaths.p39044580} fill="var(--fill-0, #F5B700)" id="Vector_214" />
          <path d={svgPaths.p278f4a80} fill="var(--fill-0, #F5B700)" id="Vector_215" />
          <path d={svgPaths.p2516ed80} fill="var(--fill-0, #F5B700)" id="Vector_216" />
          <path d={svgPaths.p12c1aa70} fill="var(--fill-0, #F5B700)" id="Vector_217" />
          <path d={svgPaths.p2069c00} fill="var(--fill-0, #0F0F12)" id="Vector_218" />
          <path d={svgPaths.p10218600} fill="var(--fill-0, #0F0F12)" id="Vector_219" />
          <path d={svgPaths.p2b05b900} fill="var(--fill-0, #0F0F12)" id="Vector_220" />
          <path d={svgPaths.p1a3f8080} fill="var(--fill-0, #F5B700)" id="Vector_221" />
          <path d={svgPaths.p12582b00} fill="var(--fill-0, #9B8500)" id="Vector_222" />
          <path d={svgPaths.p1e43abd2} fill="var(--fill-0, #F5B700)" id="Vector_223" />
          <path d={svgPaths.p1c238a00} fill="var(--fill-0, #9B8500)" id="Vector_224" />
          <path d={svgPaths.p35af7800} fill="var(--fill-0, #F5B700)" id="Vector_225" />
          <path d={svgPaths.p3696feb0} fill="var(--fill-0, #F5B700)" id="Vector_226" />
          <path d={svgPaths.p2c243540} fill="var(--fill-0, #F5B700)" id="Vector_227" />
          <path d={svgPaths.p525cf00} fill="var(--fill-0, #0F0F12)" id="Vector_228" />
          <path d={svgPaths.p307dcd00} fill="var(--fill-0, #EAEAEA)" id="Vector_229" />
          <path d={svgPaths.p30c5b900} fill="var(--fill-0, #EAEAEA)" id="Vector_230" />
          <path d={svgPaths.p3a24100} fill="var(--fill-0, #0F0F12)" id="Vector_231" />
          <path d={svgPaths.p3bc38e00} fill="var(--fill-0, #0F0F12)" id="Vector_232" />
          <path d={svgPaths.p27582680} fill="var(--fill-0, #9B8500)" id="Vector_233" />
          <path d={svgPaths.p1b20d480} fill="var(--fill-0, #F5B700)" id="Vector_234" />
          <path d={svgPaths.p22f3f3f0} fill="var(--fill-0, #9B8500)" id="Vector_235" />
          <path d={svgPaths.p174eea00} fill="var(--fill-0, #0F0F12)" id="Vector_236" />
          <path d={svgPaths.p3a03de00} fill="var(--fill-0, #0F0F12)" id="Vector_237" />
          <path d={svgPaths.p242b46c0} fill="var(--fill-0, #0F0F12)" id="Vector_238" />
          <path d={svgPaths.p186a6680} fill="var(--fill-0, #EAEAEA)" id="Vector_239" />
          <path d={svgPaths.p2e7e0200} fill="var(--fill-0, #EAEAEA)" id="Vector_240" />
          <path d={svgPaths.pd4ff380} fill="var(--fill-0, #EAEAEA)" id="Vector_241" />
          <path d={svgPaths.p2ef36da0} fill="var(--fill-0, #EAEAEA)" id="Vector_242" />
          <path d={svgPaths.p3ae12e00} fill="var(--fill-0, #0F0F12)" id="Vector_243" />
          <path d={svgPaths.p2a5b7280} fill="var(--fill-0, #0F0F12)" id="Vector_244" />
          <path d={svgPaths.p179bce00} fill="var(--fill-0, #0F0F12)" id="Vector_245" />
          <path d={svgPaths.p241a900} fill="var(--fill-0, #0F0F12)" id="Vector_246" />
          <path d={svgPaths.p33998400} fill="var(--fill-0, #0F0F12)" id="Vector_247" />
          <path d={svgPaths.p112c6b32} fill="var(--fill-0, #0F0F12)" id="Vector_248" />
          <path d={svgPaths.p114c6380} fill="var(--fill-0, #0F0F12)" id="Vector_249" />
          <path d={svgPaths.p1b6ad900} fill="var(--fill-0, #0F0F12)" id="Vector_250" />
          <path d={svgPaths.p2bbca4f0} fill="var(--fill-0, #0F0F12)" id="Vector_251" />
          <path d={svgPaths.p37be4900} fill="var(--fill-0, #0F0F12)" id="Vector_252" />
          <path d={svgPaths.p25e9a600} fill="var(--fill-0, #0F0F12)" id="Vector_253" />
        </g>
      </svg>
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-start relative shrink-0 text-[#17171c] tracking-[-0.2629px] w-[575px] whitespace-pre-wrap">
      <div className="font-['Montserrat:Bold',sans-serif] font-bold leading-[40px] relative shrink-0 text-[48px] w-full">
        <p className="mb-0">Designed once.</p>
        <p>Licensed forever.</p>
      </div>
      <p className="font-['Montserrat:Medium',sans-serif] font-medium leading-[24px] relative shrink-0 text-[24px] w-full">
        Designers publish complete UI systems.
        <br aria-hidden="true" />
        Companies license them to ship products faster.
      </p>
    </div>
  );
}

function ButtonContentArea() {
  return (
    <div className="bg-[rgba(168,230,207,0)] content-stretch flex items-center justify-center pl-[16px] pr-[300px] py-[16px] relative rounded-[8px] shrink-0" data-name="Button - Content Area">
      <div aria-hidden="true" className="absolute border border-[rgba(23,23,28,0.2)] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[14px] opacity-20 relative shrink-0 text-[#17171c] text-[14px] tracking-[-0.2629px]">YOUR EMAIL</p>
    </div>
  );
}

function TextField() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center py-[6px] relative shrink-0" data-name="text-field">
      <ButtonContentArea />
    </div>
  );
}

function ButtonContentArea1() {
  return (
    <div className="bg-[#f5b700] content-stretch flex items-center justify-center px-[38px] py-[16px] relative rounded-[8px] shrink-0" data-name="Button - Content Area">
      <p className="font-['Montserrat:Medium',sans-serif] font-medium leading-[14px] relative shrink-0 text-[#17171c] text-[14px] tracking-[-0.2629px] w-[108px] whitespace-pre-wrap">JOIN WAITLIST</p>
    </div>
  );
}

function CtaPrimary() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip py-[6px] relative shrink-0" data-name="cta-primary">
      <ButtonContentArea1 />
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <TextField />
      <CtaPrimary />
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0">
      <Frame11 />
      <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[14px] lowercase relative shrink-0 text-[#17171c] text-[14px] tracking-[-0.2629px]">We’ll email you when Bracket goes live. No spam.</p>
    </div>
  );
}

function HeroConent() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0" data-name="hero-conent">
      <Frame10 />
      <Frame9 />
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex gap-[24px] items-center relative shrink-0 w-full">
      <HeroConent />
      <div className="h-[240px] relative rounded-[20px] shrink-0 w-[400px]" data-name="61273222 1">
        <div className="absolute inset-0 overflow-hidden rounded-[20px]">
          <video autoPlay className="absolute h-[100.08%] left-[-3%] max-w-none top-[-0.04%] w-[106.75%]" controlsList="nodownload" loop playsInline>
            <source src="/_videos/v1/a35a8bf8b4ff62d1010c9535a31344ce72871f19" />
          </video>
        </div>
        <div aria-hidden="true" className="absolute border border-black border-solid inset-0 pointer-events-none rounded-[20px]" />
      </div>
    </div>
  );
}

function Frame13() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center relative shrink-0 text-[#17171c] text-center tracking-[-0.2629px]">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[40px] relative shrink-0 text-[36px]">How Bracket works</p>
      <p className="font-['Montserrat:Regular',sans-serif] font-normal leading-[20px] relative shrink-0 text-[20px] w-[728px] whitespace-pre-wrap">Publish structured systems or license proven foundations for your product.</p>
    </div>
  );
}

function Frame18() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] items-end leading-[20px] relative shrink-0 text-[#17171c] text-[20px] text-right tracking-[-0.2629px] w-[466px] whitespace-pre-wrap">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold relative shrink-0 w-full">STEP 01:</p>
      <p className="font-['Montserrat:Regular',sans-serif] font-normal relative shrink-0 w-full">Designers build complete UI systems and flows.</p>
    </div>
  );
}

function Frame15() {
  return (
    <div className="content-stretch flex gap-[58px] items-center relative shrink-0">
      <div className="h-[340px] relative rounded-[20px] shrink-0 w-[500px]" data-name="step 1 1">
        <div className="absolute inset-0 overflow-hidden rounded-[20px]">
          <video autoPlay className="absolute h-full left-[-10.41%] max-w-none top-0 w-[124.95%]" controlsList="nodownload" loop playsInline>
            <source src="/_videos/v1/0d978737779e737a85af1d013458a9e774b88bf1" />
          </video>
        </div>
        <div aria-hidden="true" className="absolute border-2 border-[#17171c] border-solid inset-0 pointer-events-none rounded-[20px]" />
      </div>
      <Frame18 />
    </div>
  );
}

function Frame19() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] items-end leading-[20px] relative shrink-0 text-[#17171c] text-[20px] tracking-[-0.2629px] w-[466px] whitespace-pre-wrap">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold relative shrink-0 w-full">STEP 02:</p>
      <p className="font-['Montserrat:Regular',sans-serif] font-normal relative shrink-0 w-full">They publish their design systems on Bracket.</p>
    </div>
  );
}

function Frame16() {
  return (
    <div className="content-stretch flex gap-[58px] items-center relative shrink-0">
      <Frame19 />
      <div className="h-[340px] relative rounded-[20px] shrink-0 w-[500px]" data-name="58592901 1">
        <div className="absolute inset-0 overflow-hidden rounded-[20px]">
          <video autoPlay className="absolute h-full left-[-10.04%] max-w-none top-0 w-[120.89%]" controlsList="nodownload" loop playsInline>
            <source src="/_videos/v1/c59cdf230d70371dc4cb40cb33c9df88cb72ffaa" />
          </video>
        </div>
        <div aria-hidden="true" className="absolute border-2 border-[#17171c] border-solid inset-0 pointer-events-none rounded-[20px]" />
      </div>
    </div>
  );
}

function Frame23() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] items-end leading-[20px] relative shrink-0 text-[#17171c] text-[20px] text-right tracking-[-0.2629px] w-[466px] whitespace-pre-wrap">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold relative shrink-0 w-full">STEP 03:</p>
      <p className="font-['Montserrat:Regular',sans-serif] font-normal relative shrink-0 w-full">Companies license ready-to-use systems to build faster.</p>
    </div>
  );
}

function Frame22() {
  return (
    <div className="content-stretch flex gap-[58px] items-center relative shrink-0">
      <div className="h-[340px] relative rounded-[20px] shrink-0 w-[500px]" data-name="step 1 1">
        <video autoPlay className="absolute max-w-none object-cover rounded-[20px] size-full" controlsList="nodownload" loop playsInline>
          <source src="/_videos/v1/0d978737779e737a85af1d013458a9e774b88bf1" />
        </video>
        <div aria-hidden="true" className="absolute border-2 border-[#17171c] border-solid inset-0 pointer-events-none rounded-[20px]" />
      </div>
      <Frame23 />
    </div>
  );
}

function Frame26() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] items-end leading-[20px] relative shrink-0 text-[#17171c] text-[20px] tracking-[-0.2629px] w-[466px] whitespace-pre-wrap">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold relative shrink-0 w-full">STEP 04:</p>
      <p className="font-['Montserrat:Regular',sans-serif] font-normal relative shrink-0 w-full">Designers earn every time their systems are licensed.</p>
    </div>
  );
}

function Frame24() {
  return (
    <div className="content-stretch flex gap-[58px] items-center relative shrink-0">
      <Frame26 />
      <div className="h-[340px] relative rounded-[20px] shrink-0 w-[500px]" data-name="58592901 1">
        <div className="absolute inset-0 overflow-hidden rounded-[20px]">
          <video autoPlay className="absolute h-full left-[-10.04%] max-w-none top-0 w-[120.89%]" controlsList="nodownload" loop playsInline>
            <source src="/_videos/v1/c59cdf230d70371dc4cb40cb33c9df88cb72ffaa" />
          </video>
        </div>
        <div aria-hidden="true" className="absolute border-2 border-[#17171c] border-solid inset-0 pointer-events-none rounded-[20px]" />
      </div>
    </div>
  );
}

function Frame17() {
  return (
    <div className="content-stretch flex flex-col gap-[36px] items-start relative shrink-0 w-full">
      <Frame15 />
      <Frame16 />
      <Frame22 />
      <Frame24 />
    </div>
  );
}

function Frame20() {
  return (
    <div className="content-stretch flex flex-col gap-[36px] items-center relative shrink-0 w-full">
      <Frame13 />
      <Frame17 />
    </div>
  );
}

function Frame28() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute content-stretch flex flex-col gap-[12px] items-center left-1/2 text-[#17171c] text-center top-1/2 w-[632px] whitespace-pre-wrap">
      <p className="font-['Montserrat:Bold',sans-serif] font-bold leading-[36px] relative shrink-0 text-[36px] tracking-[-0.2719px] w-full">Did you know?</p>
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[24px] relative shrink-0 text-[24px] tracking-[-0.2629px] w-full">Design systems usually stay unused after one client.</p>
    </div>
  );
}

function Frame29() {
  return (
    <div className="-translate-x-1/2 absolute h-[8px] left-1/2 top-[180px] w-[52px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 52 8">
        <g id="Frame 45">
          <circle cx="4" cy="4" fill="var(--fill-0, #17171C)" fillOpacity="0.6" id="Ellipse 1" r="4" />
          <circle cx="18" cy="4" fill="var(--fill-0, #17171C)" fillOpacity="0.6" id="Ellipse 2" r="4" />
          <rect fill="var(--fill-0, #F5B700)" height="8" id="Rectangle 66" rx="4" width="24" x="28" />
        </g>
      </svg>
    </div>
  );
}

function Frame27() {
  return (
    <div className="bg-[#f0f0eb] h-[200px] relative rounded-[20px] shrink-0 w-[1024px]">
      <div aria-hidden="true" className="absolute border-2 border-[rgba(23,23,28,0.4)] border-solid inset-0 pointer-events-none rounded-[20px] shadow-[0px_0px_20px_0px_rgba(0,0,0,0.2)]" />
      <Frame28 />
      <Frame29 />
    </div>
  );
}

function Frame21() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[64px] items-start left-[208px] top-[144px] w-[1024px]">
      <Frame12 />
      <Frame20 />
      <Frame27 />
    </div>
  );
}

function Frame7() {
  return (
    <div className="absolute h-[18.164px] left-[2.8px] top-[6.08px] w-[24.249px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.2493 18.1637">
        <g id="Frame 6">
          <path d={svgPaths.p182da200} fill="var(--fill-0, white)" id="{" />
          <path d={svgPaths.p3a53f700} fill="var(--fill-0, white)" id="B" />
        </g>
      </svg>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-0 top-[20px]">
      <p className="-translate-x-1/2 absolute font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[normal] left-[26px] text-[#17171c] text-[9.115px] text-center top-[66px] tracking-[-0.4065px]">© BRACKET</p>
      <div className="absolute bg-black left-[8px] overflow-clip rounded-[12px] size-[36px] top-[20px]" data-name="ic-logo">
        <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 overflow-clip size-[29.917px] top-1/2" data-name="mark">
          <Frame7 />
        </div>
      </div>
    </div>
  );
}

function Frame30() {
  return (
    <div className="absolute content-stretch flex gap-[24px] items-center left-[936px] top-[32px]">
      <div className="relative shrink-0 size-[32px]" data-name="image 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage1} />
      </div>
      <div className="relative shrink-0 size-[32px]" data-name="LI-In-Bug 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-full left-0 max-w-none top-0 w-[117.59%]" src={imgLiInBug1} />
        </div>
      </div>
    </div>
  );
}

function Frame14() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[104px] left-1/2 overflow-clip top-[calc(50%+1172px)] w-[1024px]">
      <Group2 />
      <Frame30 />
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-0 top-[2344px]">
      <div className="absolute bg-[rgba(217,217,217,0)] h-[104px] left-0 opacity-30 top-[2344px] w-[1440px]">
        <div aria-hidden="true" className="absolute border-[#17171c] border-solid border-t inset-[-0.5px_0_0_0] pointer-events-none" />
      </div>
      <Frame14 />
    </div>
  );
}

export default function LandingPageWaitlist() {
  return (
    <div className="bg-white relative size-full" data-name="landing-page-waitlist">
      <PixelArtCat />
      <BgSurface />
      <Navbar />
      <Cat />
      <Frame21 />
      <Group3 />
    </div>
  );
}